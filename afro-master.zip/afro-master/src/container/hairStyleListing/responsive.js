export const HairStyleListingSm = {
  sm: {
    "& .respnsive-img": {
      width: "96%"
    },
    "& .common-sec": {
      paddingLeft: "3%"
    },
    "& .section-hair-style-listing": {
      paddingTop: "50px;"
    },
    "& .filter-grid": {
      height: "72px",
      marginBottom: "14px !important"
    },
    "& .frist-button ": {
      marginLeft: "0px !important"
    },
    "& .tag-button button": {
      marginLeft: "0px !important",
      marginRight: "4px !important",
      padding: "0 6px !important "
    },
    "& .grid-details": {
      padding: "15px 14px 0px 2px"
    },
    "& .total-review": {
      display: "block",
      marginTop: "8px"
    },
    "& .rating button": {
      marginRight: "0px !important"
    },
    "& .product-found h3": {
      fontSize: "22px"
    },
    "& .action-grid": {
      "& .button-gallery": {
        marginLeft: "8px !important",
        width: "37% !important",
        padding: "6px 9px"
      },
      "& .button-book-an-appointment": {
        width: "60% !important",
        padding: "6px 9px"
      },
      "& div:nth-child(1)": {
        width: "60%"
      },
      "& div:nth-child(2)": {
        width: "40%"
      }
    }
  }
};
