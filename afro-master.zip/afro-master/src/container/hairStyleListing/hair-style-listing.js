import React from "react";
import {
  Grid,
  Card,
  CardContent,
  Button,
  makeStyles,
  Hidden
} from "@material-ui/core";
import "./hairStyle.scss";
import Grade from "@material-ui/icons/Grade";

import { BookingTime } from "../../components/bookAppointment/bookingTime";
import { SortByContain } from "../../components/bookAppointment/filter/sortByContain";
import { FilterContain } from "../../components/bookAppointment/filter/filterContain";
import { DrawerBooking } from "../../components/common/drawer/drawerBooking";
import { DrawerAdmin } from "../../components/common/drawer/drawerAdmin";
import { Gallery } from "../../components/gallery/gallery";
import { BottomSection } from "../../components/bookAppointment/filter/bottomSection";
import { ClicksTooltip } from "../../components/common/Tooltip/clicksTooltip";
import { HoverTooltip } from "../../components/common/Tooltip/hoverTooltip";
import { SalonList } from "../../jsonserver/hairStyleListing";
import { HairStyleListingSm } from "./responsive";
import { DialogCommon } from "../../components/common/dialogs/dialogCommon";

import filter from "../../assets/icon/filter.png";
import uncheck from "../../assets/icon/uncheck.png";
import galleryIcon from "../../assets/icon/galleryIcon.png";
import bookAppointment from "../../assets/icon/bookAppointment.png";
import tooltipDownArrow from "../../assets/icon/tooltipDownArrow.png";

const useStyles = makeStyles(theme => ({
  root: {
    [theme.breakpoints.down("sm")]: HairStyleListingSm.sm
  }
}));

export const HairStyleListing = () => {
  const classes = useStyles();
  return (
    <>
      <div className={classes.root}>
        <section
          className="section section-hair-style-listing "
          direction="row"
        >
          <Hidden only={["md", "lg"]}>
            <BottomSection />
          </Hidden>

          <Grid item xs={12} lg={8} className={` hair-style-listing`}>
            {/* filter Grid Start */}
            <Grid
              className="filter-grid common-sec"
              container
              direction="row"
              justify="center"
            >
              <Grid direction="row" container className="product-found">
                <Grid item xs={7}>
                  <h3> 235 salons available </h3>
                </Grid>
                <Hidden only={["md", "lg"]}>
                  <Grid item xs={5} className="view-map-section-xs">
                    <Button
                      className="view-map-xs"
                      variant="outlined"
                      startIcon={<img src={filter} alt="Filters icon" />}
                    >
                      Map View
                    </Button>
                  </Grid>
                </Hidden>

                <Hidden only={["sm", "xs"]}>
                  <Grid item xs={12} lg={5} className="action-sort">
                    <ClicksTooltip
                      buttonType="sort"
                      icon={<img src={uncheck} alt="Sort By icon" />}
                      classs="sort-by-button"
                      buttonText="Sort by : Relevance"
                      customClass="sort-tooltip-grid"
                    >
                      <SortByContain />
                    </ClicksTooltip>

                    <ClicksTooltip
                      buttonType="filter"
                      icon={<img src={filter} alt="Sort By icon" />}
                      classs="filter-button"
                      buttonText="Filter"
                      customClass="filter-tooltip-grid"
                    >
                      <FilterContain />
                    </ClicksTooltip>
                  </Grid>
                </Hidden>
              </Grid>
            </Grid>
            {/* filter Grid End */}

            <Grid item xs={12} lg={12}>
              <Card className="card common-sec">
                <CardContent className="card-body">
                  {SalonList.map(item => (
                    <Grid
                      direction="row"
                      container
                      key={item.id}
                      className="container-list"
                    >
                      <Grid item xs={12} sm={5} lg={5}>
                        <img
                          src={item.img}
                          className="respnsive-img"
                          alt="icon"
                        />
                      </Grid>

                      <Grid item xs={12} sm={7} lg={7} className="grid-details">
                        <Grid item xs={12} direction="row" container>
                          <Grid xs={9} lg={8} item className="title">
                            <h1> {item.name}</h1>
                            <Hidden only={["lg"]}>
                              <Grid item xs={12} className="grid-address">
                                <p> {item.address} </p>
                              </Grid>
                            </Hidden>
                          </Grid>
                          <Grid xs={3} lg={4} item className="rating">
                            <Button
                              color="primary"
                              className="rating-button"
                              size="small"
                              startIcon={<Grade />}
                            >
                              {item.rating}
                            </Button>
                            <span className="total-review">
                              {item.reviews} Reviews
                            </span>
                          </Grid>
                        </Grid>
                        <Hidden only={["xs"]}>
                          <Grid item xs={12} className="grid-address">
                            <p> {item.address} </p>
                          </Grid>
                        </Hidden>

                        <Grid item xs={12} className="tag-button">
                          {item.tags.map((tag, index) => (
                            <div key={tag.id}>
                              {index <= 2 && (
                                <Button
                                  className={`${
                                    index === 0 ? "frist-button" : ""
                                  }`}
                                  variant="outlined"
                                >
                                  {tag.label}
                                </Button>
                              )}
                            </div>
                          ))}
                          <Button variant="outlined">
                            {item.tags.length - 4} +
                          </Button>
                        </Grid>

                        <Grid item xs={12} className="time-available">
                          <span className="open-text"> Open</span>
                          <Hidden only={["md", "lg"]}>
                            <DialogCommon
                              title="Open Hours"
                              text="until 10:00 PM"
                              section="span"
                              html={`<span className="open-text"> Open</span>`}
                              icon={<img src={tooltipDownArrow} alt="Arrow" />}
                              customClass="dialog-width dialog-custom"
                            >
                              <BookingTime open={item.open} />
                            </DialogCommon>
                          </Hidden>
                          <Hidden only={["xs"]}>
                            <HoverTooltip
                              text="until 10:00 PM"
                              classes="open-time"
                              html={`<span className="open-text"> Open</span>`}
                            >
                              <BookingTime open={item.open} />
                            </HoverTooltip>
                          </Hidden>
                        </Grid>

                        <Grid item xs={12} className="action-grid">
                          <DrawerBooking
                            buttonText=" Book an Appointment"
                            classs="button-book-an-appointment"
                            icon={<img src={bookAppointment} alt="icon" />}
                          />
                          <DrawerAdmin
                            buttonText="Gallery"
                            title="Gallery"
                            icon={<img src={galleryIcon} alt="icon" />}
                            subTitle="for hair & Skin Clinic"
                            direction="right"
                            classs="button-gallery"
                          >
                            <Gallery />
                          </DrawerAdmin>
                        </Grid>
                      </Grid>
                    </Grid>
                  ))}
                </CardContent>
              </Card>
            </Grid>
          </Grid>
          <Hidden only={["sm", "xs"]}>
            <Grid item xs={12} lg={4} className="google-map-section">
              <h2> Google Map Coming Soon...</h2>
            </Grid>
          </Hidden>
        </section>
      </div>
    </>
  );
};
