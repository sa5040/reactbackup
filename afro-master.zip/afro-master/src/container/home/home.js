import React from "react";
import Hidden from '@material-ui/core/Hidden';
import './home.scss';
import { makeStyles } from '@material-ui/core';
import { SearchSalon } from '../../components/home/searchSalon';
import { HairGallery } from '../../components/home/hairGallery';
import { Products } from '../../components/home/Products';
import { IncreaseTraffic } from '../../components/home/increaseTraffic';

import TaglineBanner from '../../assets/TaglineBanner.png';
import TaglineBannerMobile from '../../assets/TaglineBannerMobile.png';


const useStyles = makeStyles(theme => ({
  root: {
    [theme.breakpoints.down('sm')]: {
      '& .section': {
        '& .bg-cover': {
          'min-height':'460px',
          'height':' 70vh',
          '& h1':{
            'margin': '0px 0px -5px 0px',
            'font-size': '17px',
            'font-family': 'IBMPlexSans',
	           'font-weight': '600',
          },
          '& h3':{
            'margin': '-10px 0px 0px 0px',
            'font-size': '17px',
            'font-family': 'IBMPlexSans',
	           'font-weight': '600',
          },
        },
      },
    },
  },
}));

export const Home = () =>{
  const classes = useStyles();
    return (
        <>
       <div className={classes.root}>  
        <section className="section section-top section-full">
           <div className="bg-cover">
            <div className="bg-container aos-init aos-animate" data-aos="fade-up">
                <h1>Find your next</h1>
                  <Hidden only={['sm', 'xs']}>  
                    <img className="responsive" src={TaglineBanner} alt="banner-img"/>
                  </Hidden >
                  <Hidden only={['md','lg','lg']}> 
                    <img className="responsive" src={TaglineBannerMobile} alt="banner-img"/>
                  </Hidden>
                <h3> in your city</h3>
                 <SearchSalon/>
            </div>
           </div>
        </section>
        </div>
        {/* Section Home Gallery start */}   
         <HairGallery/>
        {/* Section Home Gallery End*/}

         {/* Section Products start */}   
           <Products/>
         {/* Section Products End*/}

         {/* Section Increase Traffic start */}   
          <IncreaseTraffic/>
         {/* Section Increase Traffic End*/}
        </>
    )
}