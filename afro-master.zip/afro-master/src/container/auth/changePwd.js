import React from "react";
import { Grid, Container, Hidden, makeStyles} from "@material-ui/core";
import { InputField } from '../../components/formComp/InputField';
import { FormButton } from '../../components/formComp/FormButton';
import { GoBackRoute } from '../../components/routeComp/goBackRoute';
import { Logo } from '../../components/layoutComp/logo';

 import "./auth.scss";

 const useStyles = makeStyles(theme => ({
  root: {
    [theme.breakpoints.down('sm')]: {
      '& .form-screen': {
        padding: '0px 20px',
        '& .custom-input-half':{
          width:'100%'
        },
        '& .custon-ma':{
          marginLeft:'0px !important'
        },
        '& .custom-input-full': {
          width:'100%'
        },
      },
    },
  },
}));

 export const ChangePwd = () => {
  const classes = useStyles();
  return (
    <Grid container className="auth-main-grid">
     <Hidden only={["sm", "xs"]}> 
      <Grid item xs={6}>
        <div className="bg-cover-signin">
          <div className="logo-white-grid">
            <Logo/>
          </div>
        </div>
      </Grid>
      </Hidden>
      <Grid item xs={12} lg={6}  className={classes.root}>
         <Container maxWidth="sm" className="form-screen"> 
         <Hidden only={["lg", "md"]}> 
               <GoBackRoute/>
          </Hidden> 
          <div className="form-grisd-field form-input-common">
            <h3>Reset Password</h3>
            <form  noValidate>
              <Grid container spacing={2}>
                <Grid item xs={12} className="grid-input">
                  <InputField 
                    type="password"
                    className="input-text custom-input-full" 
                    name="newPassword"
                    label="New Password"/>
                </Grid>   

                <Grid item xs={12} className="grid-input">
                  <InputField 
                    type="text"
                    className="input-text custom-input-full" 
                    name="confirmNewPassword"
                    label="Confirm New Password"  />
                </Grid>    
                <FormButton type="submit" value="Submit" className="btn-common btn-change-pwd" />         
              </Grid>
            </form>
          </div>
        </Container>
      </Grid>
    </Grid>
  );
}
