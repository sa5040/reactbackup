import React, { useState } from "react";
import {
  Grid,
  Checkbox,
  FormControlLabel,
  Container,
  Hidden,
  makeStyles
} from "@material-ui/core";
import { NavLink } from "react-router-dom";
import { useForm } from "react-hook-form";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControl from "@material-ui/core/FormControl";
import { FormButton } from "../../components/formComp/FormButton";
import { Logo } from "../../components/layoutComp/logo";

import "./auth.scss";
import RadioUnchecked from "../../assets/icon/check-grey.png";
import RadioChecked from "../../assets/icon/check-selected.png";
import Male from "../../assets/icon/male.png";
import Female from "../../assets/icon/female.png";
import Other from "../../assets/icon/other.png";
import { InputField } from "../../components/formComp/InputField";
import { SchemaSignUp } from "../../components/formComp/FormRule";
import { GoBackRoute } from "../../components/routeComp/goBackRoute";

const useStyles = makeStyles(theme => ({
  root: {
    [theme.breakpoints.down("sm")]: {
      "& .form-screen": {
        padding: "0px 20px",
        "& .custom-input-half": {
          width: "100%"
        },
        "& .custon-ma": {
          marginLeft: "0px !important"
        },
        "& .custom-input-full": {
          width: "100%"
        },
        "& .radio-control-label": {
          width: "95px",
          height: "86px",
          marginLeft: "20px"
        },
        "& .gender-container :first-child": {
          marginLeft: "8px"
        },
        "& .check-add .MuiCheckbox-root": {
          top: "-7px",
          position: "absolute"
        },
        "& .check-add": {
          position: "relative"
        },
        "& .accept-term-condition .MuiTypography-root": {
          paddingLeft: "37px"
        }
      }
    }
  }
}));

export const SignUp = () => {
  const classes = useStyles();
  const [name, setName] = useState("male");
  console.log(name);

  const { register, errors, handleSubmit, formState } = useForm({
    mode: "onBlur",
    validationSchema: SchemaSignUp
  });

  const onSubmit = (data, e) => {
    e.preventDefault();
    console.log(data);
    console.log(formState);
  };

  const StyledRadio = value => (
    <Radio
      onClick={() => setName(value)}
      disableRipple
      color="default"
      checkedIcon={
        <span>
          <img src={RadioChecked} alt="checked" />
          {name === "male" && (
            <img className="gender-icon" src={Male} alt="male icon" />
          )}
          {name === "female" && (
            <img className="gender-icon" src={Female} alt="female icon" />
          )}
          {name === "other" && (
            <img className="gender-icon" src={Other} alt="other icon" />
          )}
        </span>
      }
      icon={
        <span>
          <img src={RadioUnchecked} alt="unchecked" />
          {name === "male" && (
            <img className="gender-icon 03" src={Male} alt="male icon" />
          )}
          {name === "female" && (
            <img className="gender-icon 02" src={Female} alt="female icon" />
          )}
          {name === "other" && (
            <img className="gender-icon 01" src={Other} alt="other icon" />
          )}
        </span>
      }
    />
  );

  return (
    <Grid container className="auth-main-grid">
      <Hidden only={["sm", "xs"]}>
        <Grid item xs={12} lg={6}>
          <div className="bg-cover-signup">
            <div className="logo-white-grid">
              <Logo />
            </div>
          </div>
        </Grid>
      </Hidden>
      <Grid item xs={12} lg={6} className={classes.root}>
        <Container maxWidth="sm" className="form-screen">
          <Hidden only={["lg", "md"]}>
            <GoBackRoute />
          </Hidden>
          <Hidden only={["sm", "xs"]}>
            <Grid container justify="flex-end" className="already-account-link">
              <Grid item>
                <span className="account-link"> Already have an account?</span>
                <NavLink to="/signin">
                  <FormButton
                    type="button"
                    value="Sign In"
                    className="Sign-In"
                  />
                </NavLink>
              </Grid>
            </Grid>
          </Hidden>

          <div className="form-grisd-field form-input-common">
            <h3>Sign up to Explore AfroHair Stylers!</h3>
            <form
              noValidate
              autoComplete="off"
              onSubmit={handleSubmit(onSubmit)}
            >
              <Grid container spacing={2}>
                <Grid item xs={12} sm={12} lg={5} className="grid-input">
                  <InputField
                    type="text"
                    className="input-text custom-input-half"
                    name="firstName"
                    label="First Name"
                    error={!!errors.firstName}
                    inputRef={register}
                  />

                  {errors.firstName && (
                    <div className="formError">{errors.firstName.message}</div>
                  )}
                </Grid>
                <Grid
                  item
                  xs={12}
                  sm={12}
                  lg={5}
                  className="custon-ma grid-input"
                >
                  <InputField
                    type="text"
                    className="input-text custom-input-half"
                    name="lastName"
                    label="Last Name"
                    error={!!errors.lastName}
                    inputRef={register}
                  />

                  {errors.lastName && (
                    <div className="formError">{errors.lastName.message}</div>
                  )}
                </Grid>
                <Grid item xs={12} className="grid-input">
                  <InputField
                    type="text"
                    className="input-text custom-input-full"
                    name="email"
                    label="Email address"
                    error={!!errors.email}
                    inputRef={register}
                  />

                  {errors.email && (
                    <div className="formError">{errors.email.message}</div>
                  )}
                </Grid>

                <Grid item xs={12} className="grid-input">
                  <InputField
                    type="text"
                    className="input-text custom-input-full"
                    name="password"
                    label="Password (min 8 characters)"
                    error={!!errors.password}
                    inputRef={register}
                  />

                  {errors.password && (
                    <div className="formError">{errors.password.message}</div>
                  )}
                </Grid>

                <div className="radio-section">
                  <FormControl component="fieldset">
                    <RadioGroup
                      className="gender-container"
                      defaultValue="male"
                      aria-label="gender"
                      name="customized-radios"
                    >
                      <FormControlLabel
                        value="male"
                        control={StyledRadio("male")}
                        label="MALE"
                        labelPlacement="start"
                        className={
                          "radio-control-label " +
                          (name === "male" ? "show" : "hidden")
                        }
                      />
                      <FormControlLabel
                        value="female"
                        control={StyledRadio("female")}
                        label="FEMALE"
                        labelPlacement="start"
                        className={
                          "radio-control-label " +
                          (name === "female" ? "show" : "hidden")
                        }
                      />
                      <FormControlLabel
                        value="other"
                        control={StyledRadio("other")}
                        label="OTHER"
                        labelPlacement="start"
                        className={
                          "radio-control-label " +
                          (name === "other" ? "show" : "hidden")
                        }
                      />
                    </RadioGroup>
                  </FormControl>
                </div>

                {/* End Ratio */}
                <Grid item>
                  <FormControlLabel
                    className="accept-term-condition check-singup check-add"
                    control={
                      <Checkbox value="allowExtraEmails" color="primary" />
                    }
                    label='By clicking "Sign up", you agree to AfroHairStylers Terms of Use and acknowledge you have read the Privacy Policy.'
                  />
                </Grid>
                <FormButton
                  type="submit"
                  value="Create an Account"
                  className="btn-common check-singup"
                />
              </Grid>
            </form>
          </div>
        </Container>
      </Grid>
    </Grid>
  );
};
