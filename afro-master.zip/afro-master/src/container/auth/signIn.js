import React from "react";
import { Grid, Checkbox, FormControlLabel, Container, Hidden,makeStyles} from "@material-ui/core";
import { NavLink } from "react-router-dom";
import { useForm } from 'react-hook-form';
import { FormButton } from '../../components/formComp/FormButton';
import { Logo } from '../../components/layoutComp/logo';

import { SchemasignIn } from '../../components/formComp/FormRule';
import { InputField } from '../../components/formComp/InputField';
import { GoBackRoute } from '../../components/routeComp/goBackRoute';

import "./auth.scss";
const useStyles = makeStyles(theme => ({
  root: {
    [theme.breakpoints.down('sm')]: {
      '& .form-screen': {
        padding: '0px 20px',
        '& .custom-input-half':{
          width:'100%'
        },
        '& .custon-ma':{
          marginLeft:'0px !important'
        },
        '& .custom-input-full': {
          width:'100%'
        },
      },
    },
  },
}));
 export const SignIn = () =>{
  const classes = useStyles();
  const { register, errors, handleSubmit, formState } = useForm({mode: 'onBlur', validationSchema: SchemasignIn});
  
  const onSubmit = (data, e) => {
    e.preventDefault();
    console.log(data);
    console.log(formState);
  };

  return (
    <Grid container className="auth-main-grid">
      <Hidden only={["sm", "xs"]}> 
      <Grid item xs={6}>
        <div className="bg-cover-signin">
          <div className="logo-white-grid">
            <Logo/>
          </div>
        </div>
      </Grid>
      </Hidden>
      <Grid item xs={12} lg={6}  className={classes.root}>
         <Container maxWidth="sm" className="form-screen"> 
            <Hidden only={["lg", "md"]}> 
               <GoBackRoute/>
            </Hidden>
          <div className="form-grisd-field form-input-common">
            <Hidden only={["sm", "xs"]}> 
              <Grid container justify="flex-end" className="already-account-link">
                <Grid item>
                <span className="account-link"> Don't have an account?{" "} </span>
                <NavLink to="/signup" >
                    <FormButton type="button" value="Sign Up" className="Sign-In"/> 
                </NavLink>
              </Grid>
              </Grid>
            </Hidden>

            <h3>Log in to AfroHair Stylers</h3>
            <form  noValidate autoComplete="off" onSubmit={handleSubmit(onSubmit)} >
              <Grid container spacing={2}>
              <Grid item xs={12}>
                  <InputField 
                    type="text"
                    className="input-text custom-input-full" 
                    name="email"
                    label="Email address" 
                    error={!!errors.email}
                    inputRef={register} />
                   <div className="formError">{errors.email && errors.email.message}</div>
                </Grid>

                <Grid item xs={12} >
                  <InputField 
                    type="text"
                    className="input-text custom-input-full" 
                    name="password"
                    label="Password (min 8 characters)" 
                    error={!!errors.password}
                    inputRef={register}  />
                    <div className="formError">{errors.password && errors.password.message}</div>
                </Grid>

               <Grid item className="accept-term-condition  check-singin">
                 <FormControlLabel   control={<Checkbox value="allowExtraEmails" color="primary"  name="remberMe"/>}
                    label='Remember me'/>
                     <NavLink className="forgot-link" to="/forgot-password">Forgotten account password? </NavLink>
                </Grid>
              </Grid>
              <FormButton type="submit" value="Sign In" className="btn-common" /> 
              
            </form>
          </div>
        </Container>
      </Grid>
    </Grid>
  );
}
