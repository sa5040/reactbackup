import React from "react";
import {
  Grid,
  Checkbox,
  FormControlLabel,
  Container,
  Hidden,
  makeStyles
} from "@material-ui/core";

import { InputField } from "../../components/formComp/InputField";
import { FormButton } from "../../components/formComp/FormButton";
import { GoBackRoute } from "../../components/routeComp/goBackRoute";
import { Logo } from "../../components/layoutComp/logo";

import "./auth.scss";
const useStyles = makeStyles(theme => ({
  root: {
    [theme.breakpoints.down("sm")]: {
      "& .form-screen": {
        padding: "0px 20px",
        "& .custom-input-half": {
          width: "100%"
        },
        "& .custon-ma": {
          marginLeft: "0px !important"
        },
        "& .custom-input-full": {
          width: "100%"
        },
        "& .check-add .MuiCheckbox-root": {
          top: "-7px",
          position: "absolute"
        },
        "& .check-singup": {
          position: "relative"
        },
        "& .accept-term-condition .MuiTypography-root": {
          paddingLeft: "37px"
        }
      }
    }
  }
}));

export const ListYourSalon = () => {
  const classes = useStyles();
  return (
    <Grid container className="auth-main-grid">
      <Hidden only={["sm", "xs"]}>
        <Grid item xs={12} lg={6}>
          <div className="bg-cover">
            <div className="logo-white-grid">
              <Logo />
            </div>
          </div>
        </Grid>
      </Hidden>
      <Grid item xs={12} lg={6} className={classes.root}>
        <Container maxWidth="sm" className="form-screen">
          <Hidden only={["lg", "md"]}>
            <GoBackRoute />
          </Hidden>
          <div className="form-grisd-field form-input-common">
            <h3>Let’s get started listing your salon.</h3>
            <p>List your salon with us and establish your identity</p>
            <form noValidate>
              <Grid container spacing={2}>
                <Grid item xs={12} lg={5} className="grid-input">
                  <InputField
                    type="text"
                    className="input-text custom-input-half"
                    name="firstName"
                    label="First Name"
                  />
                </Grid>
                <Grid item xs={12} lg={5} className="custon-ma grid-input">
                  <InputField
                    type="text"
                    className="input-text custom-input-half"
                    name="LastName"
                    label="Last Name"
                  />
                </Grid>
                <Grid item xs={12} className="grid-input">
                  <InputField
                    type="text"
                    className="input-text custom-input-full"
                    name="businessName"
                    label="Business Name"
                  />
                </Grid>

                <Grid item xs={12} className="grid-input">
                  <InputField
                    type="text"
                    className="input-text custom-input-full"
                    name="businessEmail"
                    label="Business Email"
                  />
                </Grid>

                <Grid item xs={12} className="grid-input">
                  <InputField
                    type="text"
                    className="input-text custom-input-full"
                    name="Password"
                    label="Password"
                  />
                </Grid>

                <Grid item xs={12} className="grid-input">
                  <InputField
                    type="text"
                    className="input-text custom-input-full"
                    name="contactNo"
                    label="Contact No"
                  />
                </Grid>

                <Grid item>
                  <FormControlLabel
                    className="accept-term-condition check-add"
                    control={
                      <Checkbox value="allowExtraEmails" color="primary" />
                    }
                    label='By clicking "Sign up", you agree to AfroHairStylers Terms of Use and acknowledge you have read the Privacy Policy.'
                  />
                </Grid>
                <FormButton
                  type="submit"
                  value="List your Salon"
                  className="btn-common btn-list-salon"
                />
              </Grid>
            </form>
          </div>
        </Container>
      </Grid>
    </Grid>
  );
};
