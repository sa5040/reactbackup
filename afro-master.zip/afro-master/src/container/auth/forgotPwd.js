import React from "react";
import { Grid,Container, Hidden, makeStyles} from "@material-ui/core";
import { NavLink } from "react-router-dom";
import { InputField } from '../../components/formComp/InputField';
import { FormButton } from '../../components/formComp/FormButton';
import { GoBackRoute } from '../../components/routeComp/goBackRoute';
import { Logo } from '../../components/layoutComp/logo';

import "./auth.scss";

const useStyles = makeStyles(theme => ({
  root: {
    [theme.breakpoints.down('sm')]: {
      '& .form-screen': {
        padding: '0px 20px',
        '& .custom-input-half':{
          width:'100%'
        },
        '& .custon-ma':{
          marginLeft:'0px !important'
        },
        '& .custom-input-full': {
          width:'100%'
        },
      },
    },
  },
}));

 export const ForgotPwd = () => {
  const classes = useStyles();
  return (
    <Grid container className="auth-main-grid">
       <Hidden only={["sm", "xs"]}> 
        <Grid item xs={12} lg={6}>
          <div className="bg-cover-signin">
            <div className="logo-white-grid">
              <Logo/>
            </div>
          </div>
        </Grid>
      </Hidden>
      <Grid item xs={12} lg={6}  className={classes.root}>
         <Container maxWidth="sm" className="form-screen"> 
           <Hidden only={["lg", "md"]}> 
               <GoBackRoute/>
            </Hidden>
          <div className="form-grisd-field form-input-common">
          <Hidden only={["sm", "xs"]}> 
            <Grid container justify="flex-end" className="already-account-link">
               <Grid item>
                  <span className="account-link">  Already have an account?</span>
                  <NavLink to="/signin" >
                      <FormButton type="button" value="Sign In" className="Sign-In"/> 
                  </NavLink>
              </Grid>
            </Grid>
            </Hidden>

            <h3 className="h3-heading">Forgot Password</h3>
            <div className="title-pwd">Enter your email address to retreive your password.</div>
            <form  noValidate>
              <Grid container spacing={2}>
                 <Grid item xs={12}>
                  <InputField 
                    type="text"
                    className="input-text custom-input-full" 
                    name="emailAddress"
                    label="Email address"  />
                </Grid>

                <FormButton type="submit" value="Reset Password" className="btn-common btn-reset-pwd" /> 
              </Grid>
            </form>
          </div>
        </Container>
      </Grid>
    </Grid>
  );
}
