import React from "react";

import InputAdornment from "@material-ui/core/InputAdornment";

import TextField from "@material-ui/core/TextField";

export const Finances = () => {
  return (
    <div>
      <TextField
        label="Charges"
        id="outlined-start-adornment"
        InputProps={{
          startAdornment: <InputAdornment position="start">$</InputAdornment>
        }}
        variant="outlined"
      />
    </div>
  );
};
