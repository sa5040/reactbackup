import React from "react";
import { Grid, Box, Button, Avatar } from "@material-ui/core";
import { DrawerAdmin } from "../../components/common/drawer/drawerAdmin";
import { AddNewEmploy } from "../../components/salonAdmin/addNewEmploy";
import "./salonAdmin.scss";
import ovalThree from "../../assets/banner/ovalThree.png";

export const Employee = () => {
  return (
    <div className="section-admin-form ">
      {/*  Service */}
      <div className="section-employee">
        <Grid container direction="row">
          <Grid container direction="row" className="top-section">
            <Grid item xs={6} lg={6}>
              <h3 className="heading">Employee</h3>
            </Grid>
            <Grid
              item
              xs={6}
              lg={6}
              className="section-button form-input-common"
            >
              <DrawerAdmin
                direction="right"
                title="Add New Employee"
                buttonText="Add New Employee"
                classs="black-button add-button-new-emp"
              >
                <AddNewEmploy />
              </DrawerAdmin>
            </Grid>
          </Grid>

          {[1, 2].map(items => (
            <Grid
              container
              direction="row"
              className="employee-main-grid"
              key={items}
            >
              <Grid item xs={12} lg={12} className="section-info">
                <div className="location">Location </div>
                <div className="address">
                  J-450, Cleo County, Noida Sector 71, Greater Noida
                </div>
              </Grid>

              {[1, 2, 3, 4].map(item => (
                <Grid
                  item
                  xs={12}
                  md={6}
                  lg={6}
                  className="employee-grid"
                  key={item}
                >
                  <Box width="100%" display="flex">
                    <Box width="20%">
                      <Avatar
                        alt="Remy Sharp"
                        src={ovalThree}
                        className="img-round"
                      />
                    </Box>
                    <Box width="80%" className="emp-info">
                      <div className="edit">
                        <Button size="small" className="edit-button">
                          {" "}
                          Edit{" "}
                        </Button>
                      </div>
                      <div className="name"> Jordan Ntolo</div>
                      <div className="number"> 346 6776 560</div>
                      <div className="email"> simon.kovac@hairandskin.com</div>
                      <div className="tags">
                        {" "}
                        Nail Treatment, Hair Waxing, Hair Cutting and 2 more
                      </div>
                    </Box>
                  </Box>
                </Grid>
              ))}
            </Grid>
          ))}
        </Grid>
      </div>
      {/* End */}
    </div>
  );
};
