import React from "react";
import {
  Grid,
  makeStyles,
  Card,
  CardActionArea,
  CardContent,
  CardMedia,
  ExpansionPanel,
  ExpansionPanelDetails,
  ExpansionPanelSummary,
  Typography
} from "@material-ui/core";

import { Add, Edit } from "@material-ui/icons";
import { DrawerAdmin } from "../../components/common/drawer/drawerAdmin";
import { AddNewCategory } from "../../components/salonAdmin/addNewCategory";
import { AddNewService } from "../../components/salonAdmin/addNewService";
import "./salonAdmin.scss";
import groupImg from "../../assets/banner/groupImg.png";
import groupThree from "../../assets/banner/groupThree.png";
import groupTwo from "../../assets/banner/groupTwo.png";

const useStyles = makeStyles(theme => ({
  root: {
    "& > *": {
      margin: theme.spacing(1)
    }
  },
  media: {
    height: 180
  },
  card: {
    maxWidth: 180,
    minWidth: 180,
    padding: "0px"
  }
}));

export const Services = () => {
  const classes = useStyles();
  return (
    <div className="section-admin-form form-input-common">
      {/*  Service */}
      <div className="section-salon-service">
        <Grid container direction="row">
          <Grid container direction="row" className="top-section">
            <Grid item xs={6} lg={6}>
              <h3 className="heading">Salon Services</h3>
            </Grid>
            <Grid item xs={6} lg={6} className="section-button">
              <DrawerAdmin
                direction="right"
                title="Add New Category"
                buttonText="Add New Category"
                classs="white-button add-button-new"
              >
                <AddNewCategory />
              </DrawerAdmin>

              <DrawerAdmin
                direction="right"
                title="Add New Service"
                buttonText="Add New Service"
                classs="black-button add-button-new-ser"
              >
                <AddNewService />
              </DrawerAdmin>
            </Grid>
          </Grid>
          <Grid item xs={12} md={12} lg={12} className="expansion-grid">
            <div>
              <ExpansionPanel>
                <ExpansionPanelSummary
                  expandIcon={<Add />}
                  aria-controls="panel1bh-content"
                  id="panel1bh-header"
                >
                  <Typography className="tab-title">
                    Hair Cutting <span>( 10 Styles)</span>
                  </Typography>
                </ExpansionPanelSummary>
                <ExpansionPanelDetails>
                  <Grid container direction="row">
                    {[1, 2, 3, 4, 5, 6].map(item => (
                      <div className="service-grid" key={item}>
                        <Card className={`${classes.card} profile-card`}>
                          <CardActionArea>
                            <div className="image-text">
                              <div className="top-icon">
                                {" "}
                                <Edit />
                              </div>
                              <div className="botton-text"> 2hrs 30 Minuts</div>
                            </div>
                            <CardMedia
                              className={classes.media}
                              image={groupImg}
                              title="map"
                            />
                            <CardContent>
                              <div className="service-name">Adam Denisov</div>
                              <div className="service-price">$109.00</div>
                            </CardContent>
                          </CardActionArea>
                        </Card>
                      </div>
                    ))}
                  </Grid>
                </ExpansionPanelDetails>
              </ExpansionPanel>
              <ExpansionPanel>
                <ExpansionPanelSummary
                  expandIcon={<Add />}
                  aria-controls="panel2bh-content"
                  id="panel2bh-header"
                >
                  <Typography className="tab-title">
                    Nail Treatment <span>( 10 Styles)</span>
                  </Typography>
                </ExpansionPanelSummary>
                <ExpansionPanelDetails>
                  <Grid container direction="row">
                    {[1, 2, 3, 4, 5, 6].map(item => (
                      <div className="service-grid" key={item}>
                        <Card className={`${classes.card} profile-card`}>
                          <CardActionArea>
                            <div className="image-text">
                              <div className="top-icon">
                                {" "}
                                <Edit />
                              </div>
                              <div className="botton-text"> 2hrs 30 Minuts</div>
                            </div>
                            <CardMedia
                              className={classes.media}
                              image={groupTwo}
                              title="map"
                            />
                            <CardContent>
                              <div className="service-name">Adam Denisov</div>
                              <div className="service-price">$109.00</div>
                            </CardContent>
                          </CardActionArea>
                        </Card>
                      </div>
                    ))}
                  </Grid>
                </ExpansionPanelDetails>
              </ExpansionPanel>
              <ExpansionPanel>
                <ExpansionPanelSummary
                  expandIcon={<Add />}
                  aria-controls="panel3bh-content"
                  id="panel3bh-header"
                >
                  <Typography className="tab-title">
                    Hair Waxing <span>( 10 Styles)</span>
                  </Typography>
                </ExpansionPanelSummary>
                <ExpansionPanelDetails>
                  <Grid container direction="row">
                    {[1, 2, 3, 4, 5, 6].map(item => (
                      <div className="service-grid" key={item}>
                        <Card className={`${classes.card} profile-card`}>
                          <CardActionArea>
                            <div className="image-text">
                              <div className="top-icon">
                                {" "}
                                <Edit />
                              </div>
                              <div className="botton-text"> 2hrs 30 Minuts</div>
                            </div>
                            <CardMedia
                              className={classes.media}
                              image={groupThree}
                              title="map"
                            />
                            <CardContent>
                              <div className="service-name">Adam Denisov</div>
                              <div className="service-price">$109.00</div>
                            </CardContent>
                          </CardActionArea>
                        </Card>
                      </div>
                    ))}
                  </Grid>
                </ExpansionPanelDetails>
              </ExpansionPanel>
            </div>
          </Grid>
        </Grid>
      </div>
      {/* End */}
    </div>
  );
};
