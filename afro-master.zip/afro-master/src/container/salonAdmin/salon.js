import React from "react";
import { makeStyles, Grid } from "@material-ui/core";
import { useForm } from "react-hook-form";
import {
  Card,
  CardActionArea,
  CardActions,
  CardContent,
  CardMedia,
  Typography
} from "@material-ui/core";
import { Add, Edit } from "@material-ui/icons";

import "./salonAdmin.scss";
import profileIcon from "../../assets/banner/profileIcon.PNG";
import mapImg from "../../assets/banner/mapImg.PNG";
import { InputField } from "../../components/formComp/InputField";
import { FormButton } from "../../components/formComp/FormButton";
import { SchemaUpdateProfile } from "../../components/formComp/FormRule";
import { DrawerAdmin } from "../../components/common/drawer/drawerAdmin";
import { AddNewAddress } from "../../components/salonAdmin/addNewAddress";

const useStyles = makeStyles(theme => ({
  root: {
    "& > *": {
      margin: theme.spacing(1)
    }
  },
  input: {
    display: "none"
  },
  media: {
    height: 140
  },
  card: {
    maxWidth: 375,
    padding: "20px"
  }
}));

export const Salon = () => {
  const classes = useStyles();
  const { register, errors, handleSubmit, formState } = useForm({
    mode: "onBlur",
    validationSchema: SchemaUpdateProfile
  });

  const onSubmit = (data, e) => {
    e.preventDefault();
    console.log(data);
    console.log(formState);
  };

  return (
    <div className="section-admin-form form-input-common">
      {/*  Salon Profile  */}
      <div className="section-salon-profile">
        <form noValidate autoComplete="off" onSubmit={handleSubmit(onSubmit)}>
          <h3 className="heading salon-profile">Salon Profile</h3>
          <Grid container direction="row">
            <Grid item xs={12} md={5} lg={5} className="input-grid">
              <Grid item xs={12} className="grid-input">
                <InputField
                  type="text"
                  className="input-text"
                  name="businessName"
                  error={!!errors.businessName}
                  label="Business Name"
                  inputRef={register}
                />
                {errors.businessName && (
                  <div className="formError">{errors.businessName.message}</div>
                )}
              </Grid>

              <Grid item xs={12} className="grid-input">
                <InputField
                  type="text"
                  className="input-text"
                  label="Business Registration Number"
                  name="businessRegistrationNumber"
                  error={!!errors.lastName}
                  inputRef={register}
                />
                {errors.businessRegistrationNumber && (
                  <div className="formError">
                    {errors.businessRegistrationNumber.message}
                  </div>
                )}
              </Grid>

              <Grid item xs={12} className="grid-input">
                <InputField
                  type="text"
                  className="input-text"
                  label="VAT/Tax Number"
                  name="vatTaxNumber"
                  error={!!errors.email}
                  inputRef={register}
                />
                {errors.vatTaxNumber && (
                  <div className="formError">{errors.vatTaxNumber.message}</div>
                )}
              </Grid>
            </Grid>
            <Grid item xs={12} md={3} lg={3} className="profile-img-sec">
              <p>Business Logo</p>
              <div className="upload-img">
                <img src={profileIcon} alt="profile icon" />{" "}
              </div>
              <input
                accept="image/*"
                className={classes.input}
                id="contained-button-file"
                multiple
                type="file"
              />
              <label htmlFor="contained-button-file">
                <FormButton
                  type="submit"
                  value="Add"
                  className="add-button white-button"
                  component="span"
                />
              </label>
            </Grid>

            <Grid item xs={12} className="salon-photos-section">
              <div className="title">Salon Photos</div>
              <span className="sub-title">( You can add upto 15 Photos)</span>
              <Grid container direction="row">
                <div className="rectangle-photo add-more">
                  <div className="add-more-icon">
                    <div>
                      <Add />
                    </div>
                    Add More
                  </div>
                </div>
                <div className="rectangle-photo"> </div>
                <div className="rectangle-photo"> </div>
                <div className="rectangle-photo"> </div>
                <div className="rectangle-photo"> </div>
              </Grid>
            </Grid>
            <Grid item xs={12} className="action-grid-common">
              <FormButton
                type="submit"
                value="Update"
                className="black-button update-button"
              />
            </Grid>
          </Grid>
        </form>
      </div>
      {/* End Update Profile End */}

      {/* Salon Location*/}
      <div className="section-contact">
        <form noValidate autoComplete="off">
          <h3 className="Salon-Admin-Profile heading">Salon Location</h3>
          <Grid container direction="row">
            <Grid item xs={12} md={5} lg={5}>
              <Card className={`${classes.card} address-card`}>
                <div className="location">Location 1</div>
                <CardActionArea>
                  <CardMedia
                    className={classes.media}
                    image={mapImg}
                    title="map"
                  />
                  <CardContent>
                    <Typography
                      variant="body2"
                      color="textSecondary"
                      component="p"
                      className="address"
                    >
                      J-450, Cleo County, Noida Sector 71, Greater Noida, Near
                      Post Office, India 110004
                    </Typography>
                  </CardContent>
                </CardActionArea>
                <CardActions>
                  <DrawerAdmin
                    direction="right"
                    title="Edit New Address"
                    buttonText="Edit Address"
                    color="primary"
                    size="small"
                    icon={<Edit />}
                    classs="white-button edit-address-button"
                  >
                    <AddNewAddress />
                  </DrawerAdmin>
                </CardActions>
              </Card>
            </Grid>

            <Grid item xs={12} md={7} lg={12} className="action-grid-common">
              <DrawerAdmin
                direction="right"
                title="Add New Address"
                buttonText="Add New Address"
                classs="add-new-address-button"
              >
                <AddNewAddress />
              </DrawerAdmin>
            </Grid>
          </Grid>
        </form>
      </div>
      {/* Salon Location End */}
    </div>
  );
};
