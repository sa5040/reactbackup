import React from "react";
import { makeStyles, Grid } from "@material-ui/core";
import { useForm } from "react-hook-form";

import "./salonAdmin.scss";
import profileIcon from "../../assets/banner/profileIcon.PNG";
import { InputField } from "../../components/formComp/InputField";
import { InputTextarea } from "../../components/formComp/InputTextarea";
import { FormButton } from "../../components/formComp/FormButton";
import { SchemaUpdateProfile } from "../../components/formComp/FormRule";

const useStyles = makeStyles(theme => ({
  root: {
    "& > *": {
      margin: theme.spacing(1)
    }
  },
  input: {
    display: "none"
  }
}));

export const Profile = () => {
  const classes = useStyles();
  const { register, errors, handleSubmit, formState } = useForm({
    mode: "onBlur",
    validationSchema: SchemaUpdateProfile
  });

  const onSubmit = (data, e) => {
    e.preventDefault();
    console.log(data);
    console.log(formState);
  };

  return (
    <div className="section-admin-form form-input-common">
      {/*  Update Profile  */}
      <div className="section-update-profile">
        <form noValidate autoComplete="off" onSubmit={handleSubmit(onSubmit)}>
          <p className="profile-name">Hello Vijay Singh Bisht</p>
          <h3 className="Salon-Admin-Profile heading">Salon Admin Profile</h3>
          <Grid container direction="row">
            <Grid item xs={12} md={5} lg={5} className="input-grid">
              <Grid item xs={12} className="grid-input">
                <InputField
                  type="text"
                  className="input-text"
                  name="firstName"
                  error={!!errors.firstName}
                  label="First Name"
                  inputRef={register}
                />
                {errors.firstName && (
                  <div className="formError">{errors.firstName.message}</div>
                )}
              </Grid>

              <Grid item xs={12} className="grid-input">
                <InputField
                  type="text"
                  className="input-text"
                  label="Last Name"
                  name="lastName"
                  error={!!errors.lastName}
                  inputRef={register}
                />
                {errors.lastName && (
                  <div className="formError">{errors.lastName.message}</div>
                )}
              </Grid>

              <Grid item xs={12}>
                <InputField
                  type="text"
                  className="input-text"
                  label="Email"
                  name="email"
                  error={!!errors.email}
                  inputRef={register}
                />
                {errors.email && (
                  <div className="formError">{errors.email.message}</div>
                )}
              </Grid>

              <Grid item xs={12} className="action-grid-common">
                <FormButton
                  type="submit"
                  value="Update"
                  className="update-button-profile black-button"
                />
              </Grid>
            </Grid>
            <Grid item xs={12} md={3} lg={3} className="profile-img-sec">
              <p>Profile Picture</p>
              <div className="upload-img">
                <img src={profileIcon} alt="profile icon" />{" "}
              </div>
              <input
                accept="image/*"
                className={classes.input}
                id="contained-button-file"
                multiple
                type="file"
              />
              <label htmlFor="contained-button-file">
                <FormButton
                  type="submit"
                  value="Add"
                  className="white-button add-button"
                  component="span"
                />
              </label>
            </Grid>
          </Grid>
        </form>
      </div>
      {/* End Update Profile End */}

      {/* Salon Admin Contact*/}
      <div className="section-contact">
        <form noValidate autoComplete="off">
          <h3 className="salon-admin-contact heading">Salon Admin Contact</h3>
          <Grid container direction="row">
            <Grid
              item
              xs={12}
              md={12}
              lg={12}
              className="grid-input-half"
              container
              direction="row"
            >
              <Grid item xs={12} md={5} lg={5}>
                <InputField
                  type="text"
                  className="input-text"
                  label="Country"
                />
              </Grid>

              <Grid item xs={12} md={5} lg={7}>
                <InputField
                  type="text"
                  className="input-text"
                  label="City/Town"
                />
              </Grid>
            </Grid>

            <Grid
              item
              xs={12}
              md={12}
              slg={12}
              className="grid-input"
              container
              direction="row"
            >
              <Grid item xs={12} md={5} lg={5}>
                <InputField
                  type="text"
                  className="input-text"
                  label="Postcode"
                />
              </Grid>

              <Grid item xs={12} md={7} lg={7}>
                <InputField
                  type="text"
                  className="input-text"
                  label="Telephone"
                />
              </Grid>
            </Grid>

            <Grid item xs={12} md={12} lg={12}>
              <InputTextarea
                label="Street Address"
                rows="4"
                className="input-text"
              />
            </Grid>

            <Grid item xs={12} md={7} lg={7} className="action-grid-common">
              <FormButton
                value="Update"
                className="update-button-profile black-button"
              />
            </Grid>
          </Grid>
        </form>
      </div>
      {/* Salon Admin End */}

      {/*  Change Password */}
      <div className="section-change-password">
        <form noValidate autoComplete="off">
          <h3 className="salon-admin-contact heading">Change Password</h3>
          <Grid container direction="row">
            <Grid item xs={12} md={12} lg={12} className="grid-input">
              <InputField
                type="password"
                className="input-text"
                label="Old Password"
              />
            </Grid>

            <Grid item xs={12} md={12} lg={12} container direction="row">
              <Grid item xs={12} md={5} lg={5}>
                <InputField
                  type="password"
                  className="input-text"
                  label="New Password"
                />
              </Grid>

              <Grid item xs={12} md={7} lg={7}>
                <InputField
                  type="password"
                  className="input-text"
                  label="Confirm Password"
                />
              </Grid>
            </Grid>

            <Grid item xs={12} md={7} lg={7} className="action-grid-common">
              <FormButton
                value="Update"
                className="update-button-profile black-button"
              />
            </Grid>
          </Grid>
        </form>
      </div>
      {/*  Change Password End */}
    </div>
  );
};
