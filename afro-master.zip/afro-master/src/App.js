import React from "react";
import { Container } from "@material-ui/core";
import { MainRoute } from "./components/routeComp/router";

function App() {
  return (
    <React.Fragment>
      <Container disableGutters={true} maxWidth={false}>
        <MainRoute />
      </Container>
    </React.Fragment>
  );
}

export default App;
