import salon from "../assets/banner/salon.png";
import salon2 from "../assets/banner/salon2.jpg";
import salon3 from "../assets/banner/salon3.png";

import rectangle420 from "../assets/banner/rectangle420.png";
import rectangle4201 from "../assets/banner/rectangle4201.png";
import rectangle4202 from "../assets/banner/rectangle4202.png";
export const SalonList = [
  {
    id: 1,
    name: "Hair & Skin Clinic",
    address: "Unit 11, Ansty Court, 44 Kenyon Street, Jewellery Birmingham",
    rating: "3.7",
    reviews: "76",
    phone: ["+44-80905500", "+44-80905590"],
    email: "hairnskin@afrohair.com",
    open: [
      {
        id: 1,
        day: "Monday",
        time: "10:00 AM - 10 :00 PM",
        status: "active"
      },
      {
        id: 2,
        day: "Tuesday",
        time: "10:00 AM - 10 :00 PM",
        status: "active"
      },
      {
        id: 3,
        day: "Wednesday",
        time: "10:00 AM - 10 :00 PM",
        status: "active"
      },
      {
        id: 4,
        day: "Thursday",
        time: "10:00 AM - 10 :00 PM",
        status: "active"
      },
      {
        id: 5,
        day: "Friday",
        time: "10:00 AM - 10 :00 PM",
        status: "active"
      },
      {
        id: 6,
        day: "Saturday",
        time: "10:00 AM - 10 :00 PM",
        status: "active"
      },
      { id: 7, day: "Sunday", time: "10:00 AM - 10 :00 PM", status: "active" }
    ],
    tags: [
      { id: 1, label: "Hair cutting" },
      { id: 2, label: "Hair colouring" },
      { id: 3, label: "Hair cutting" },
      { id: 4, label: "Hair styling" },
      { id: 5, label: "Nail treatments" }
    ],
    img: salon
  },
  {
    id: 2,
    name: "Pickles & Co",
    address: "Unit 11, Ansty Court, 44 Kenyon Street, Jewellery Birmingham",
    rating: "2.7",
    reviews: "76",
    phone: ["+44-80905500", "+44-80905590"],
    email: "hairnskin@afrohair.com",
    open: [
      {
        id: 1,
        day: "Monday",
        time: "10:00 AM - 10 :00 PM",
        status: "active"
      },
      {
        id: 2,
        day: "Tuesday",
        time: "10:00 AM - 10 :00 PM",
        status: "active"
      },
      {
        id: 3,
        day: "Wednesday",
        time: "10:00 AM - 10 :00 PM",
        status: "active"
      },
      {
        id: 4,
        day: "Thursday",
        time: "10:00 AM - 10 :00 PM",
        status: "active"
      },
      {
        id: 5,
        day: "Friday",
        time: "10:00 AM - 10 :00 PM",
        status: "active"
      },
      {
        id: 6,
        day: "Saturday",
        time: "10:00 AM - 10 :00 PM",
        status: "active"
      },
      { id: 7, day: "Sunday", time: "10:00 AM - 10 :00 PM", status: "active" }
    ],
    tags: [
      { id: 1, label: "Hair cutting" },
      { id: 2, label: "Hair colouring" },
      { id: 3, label: "Hair cutting" },
      { id: 4, label: "Hair styling" }
    ],
    img: salon2
  },
  {
    id: 3,
    name: "Blow LTD Birmingham",
    address: "Unit 11, Ansty Court, 44 Kenyon Street, Jewellery Birmingham",
    rating: "4.7",
    reviews: "101",
    phone: ["+44-80905500", "+44-80905590"],
    email: "hairnskin@afrohair.com",
    open: [
      {
        id: 1,
        day: "Monday",
        time: "10:00 AM - 10 :00 PM",
        status: "active"
      },
      {
        id: 2,
        day: "Tuesday",
        time: "10:00 AM - 10 :00 PM",
        status: "active"
      },
      {
        id: 3,
        day: "Wednesday",
        time: "10:00 AM - 10 :00 PM",
        status: "active"
      },
      {
        id: 4,
        day: "Thursday",
        time: "10:00 AM - 10 :00 PM",
        status: "active"
      },
      {
        id: 5,
        day: "Friday",
        time: "10:00 AM - 10 :00 PM",
        status: "active"
      },
      {
        id: 6,
        day: "Saturday",
        time: "10:00 AM - 10 :00 PM",
        status: "active"
      },
      { id: 7, day: "Sunday", time: "10:00 AM - 10 :00 PM", status: "active" }
    ],
    tags: [
      { id: 1, label: "Hair cutting" },
      { id: 2, label: "Hair colouring" },
      { id: 3, label: "Hair cutting" }
    ],
    img: salon3
  }
];

// Salon Details
export const SalonDetailsJson = [
  {
    id: 1,
    name: "Hair & Skin Clinic",
    address: "Unit 11, Ansty Court, 44 Kenyon Street, Jewellery Birmingham",
    rating: "4.6",
    reviews: "65,410",
    groupreviews: [
      {
        totalreviews: 2000,
        five: 1000,
        four: 400,
        three: 300,
        two: 200,
        one: 100
      }
    ],
    totalreviews: [
      {
        name: "Emelda Scandroot",
        rating: "4",
        text: "Great ambience",
        date: "1 day ago",
        category: "most-helpful"
      },
      {
        name: "Emelda Scandroot",
        rating: "4",
        text: "Great ambience",
        date: "1 day ago",
        category: "latest"
      },
      {
        name: "Emelda Scandroot",
        rating: "4",
        text: "Great ambience",
        date: "1 day ago",
        category: "most-helpful"
      },
      {
        name: "Emelda Scandroot",
        rating: "4",
        text: "Great ambience",
        date: "1 day ago",
        category: "most-critical"
      }
    ],
    phone: ["+44-80905500", "+44-80905590"],
    email: "hairnskin@afrohair.com",
    locations: [
      {
        address:
          "J-450, Cleo County, Noida Sector 71, Greater Noida, Near Post Office, India 110004",
        phone: ["+44-80905590", "+44-80905500"]
      },
      {
        address:
          "J-450, Cleo County, Noida Sector 71, Greater Noida, Near Post Office, India 110004",
        phone: ["+44-80905590", "+44-80905500"]
      },
      {
        address:
          "J-450, Cleo County, Noida Sector 71, Greater Noida, Near Post Office, India 110004",
        phone: ["+44-80905590", "+44-80905500"]
      }
    ],
    gallery: [rectangle420, rectangle4201, rectangle4202],
    open: [
      {
        id: 1,
        day: "Monday",
        time: "10:00 AM - 10 :00 PM",
        status: "active"
      },
      {
        id: 2,
        day: "Tuesday",
        time: "10:00 AM - 10 :00 PM",
        status: "active"
      },
      {
        id: 3,
        day: "Wednesday",
        time: "10:00 AM - 10 :00 PM",
        status: "active"
      },
      {
        id: 4,
        day: "Thursday",
        time: "10:00 AM - 10 :00 PM",
        status: "active"
      },
      {
        id: 5,
        day: "Friday",
        time: "10:00 AM - 10 :00 PM",
        status: "active"
      },
      {
        id: 6,
        day: "Saturday",
        time: "10:00 AM - 10 :00 PM",
        status: "active"
      },
      { id: 7, day: "Sunday", time: "10:00 AM - 10 :00 PM", status: "active" }
    ],
    tags: [
      { id: 1, label: "Hair cutting" },
      { id: 2, label: "Hair colouring" },
      { id: 3, label: "Hair cutting" },
      { id: 4, label: "Hair styling" },
      { id: 5, label: "Nail treatments" }
    ],
    img: salon
  }
];
