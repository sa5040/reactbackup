import React from "react";
import InputLabel from "@material-ui/core/InputLabel";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import "./formComp.scss";

export const SelectField = props => {
  const [state, setState] = React.useState({
    value: ""
  });

  const handleChange = event => {
    const name = event.target.name;
    setState({
      ...state,
      [name]: event.target.value
    });
  };

  return (
    <>
      <FormControl variant="outlined">
        <InputLabel htmlFor="outlined-age-native-simple">
          {props.label}
        </InputLabel>
        <Select
          className={`input-text ${props.classs} `}
          native
          value={state.value}
          onChange={handleChange}
          label={props.label}
          inputProps={{
            name: props.label,
            id: "outlined-age-native-simple"
          }}
        >
          {props.options.map(item => (
            <option key={item} value={item}>
              {item}
            </option>
          ))}
        </Select>
      </FormControl>
    </>
  );
};
