import React from "react";
import Button from "@material-ui/core/Button";
export const FormButton = props => {
  return (
    <Button
      className={`${props.classs} btn-common-class`}
      variant="contained"
      {...props}
    >
      {props.value}
    </Button>
  );
};
