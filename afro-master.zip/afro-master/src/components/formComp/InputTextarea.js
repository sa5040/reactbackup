import React from "react";
import { TextField } from "@material-ui/core";
export const InputTextarea = props => {
  return <TextField variant="outlined" fullWidth multiline {...props} />;
};
