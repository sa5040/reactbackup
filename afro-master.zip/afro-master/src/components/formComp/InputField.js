import React from "react";
import { TextField } from "@material-ui/core";
import "./formComp.scss";
import { makeStyles } from "@material-ui/core";

const useStyles = makeStyles(theme => ({
  input1: {
    height: 17
  },
  input2: {
    height: 54,
    fontSize: "1em"
  }
}));

export const InputField = React.forwardRef((props, ref) => {
  const classes = useStyles();
  return (
    <TextField
      ref={ref}
      InputProps={{ classes: { input: classes.input1 } }}
      fullWidth
      variant="outlined"
      {...props}
    />
  );
});
