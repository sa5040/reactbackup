import React from 'react';
import { makeStyles ,withStyles,fade} from '@material-ui/core';
import InputLabel from '@material-ui/core/InputLabel';
import FormControl from '@material-ui/core/FormControl';
import InputBase from '@material-ui/core/InputBase';
import './formComp.scss';

const useStyles = makeStyles(theme => ({
  input1: {
    height: 17
  },
  input2: {
    height: 54,
    fontSize: "1em"
  }
}));

const BootstrapInput = withStyles((theme) => ({
    root: {
      'label + &': {
        marginTop: theme.spacing(3),
      },
    },
    input: {
      borderRadius: 0,
      position: 'relative',
      backgroundColor: theme.palette.common.white,
      border: 'solid 0.5px #dde5ed',
      boxShadow:'0 2px 11px 0 rgba(221, 229, 237, 0.33)',
      fontSize: 14,
      padding: '10px 12px',
      height:'30px',
      transition: theme.transitions.create(['border-color', 'box-shadow']),
      '&:focus': {
        boxShadow: `${fade(theme.palette.primary.main, 0.25)} 0 0 0 0.2rem`,
        borderColor: theme.palette.primary.main,
      },
    },
}))(InputBase);

export const InputFieldBootstrap = React.forwardRef((props, ref) => {
 const classes = useStyles();
 return (
    <FormControl className={`${classes.margin}  boostrap-style`}>
      {/*<InputLabel shrink htmlFor="bootstrap-input"> {props.label} </InputLabel> */}
      <BootstrapInput  
       ref={ref}  
       placeholder={props.label}
       {...props}/>
    </FormControl>
 );
});



