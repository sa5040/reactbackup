import * as yup from "yup";
export const formRule = {
  updateProfile: {
    firstName: yup.string().required("Please enter first name"),
    lastName: yup.string().required("Please enter last name"),
    email: yup
      .string()
      .email("Please Enter Valid Email Address")
      .required("Please enter email address")
  },
  signIn: {
    password: yup.string().required("Please Enter Password"),
    email: yup
      .string()
      .email("Please Enter Valid Email Address")
      .required("Please enter email address")
  },
  signUp: {
    firstName: yup.string().required("Please enter first name"),
    lastName: yup.string().required("Please enter last name"),
    email: yup
      .string()
      .email("Please Enter Valid Email Address")
      .required("Please enter email address"),
    password: yup.string().required("Please enter password")
  }
};

export const SchemaUpdateProfile = yup.object().shape(formRule.updateProfile);
export const SchemasignIn = yup.object().shape(formRule.signIn);
export const SchemaSignUp = yup.object().shape(formRule.signUp);
