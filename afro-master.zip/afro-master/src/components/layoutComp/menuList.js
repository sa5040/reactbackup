import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import Collapse from "@material-ui/core/Collapse";
import arrowGreyDown from "../../assets/icon/arrowGreyDown.png";
import { NavLink } from "react-router-dom";

import { TouchWithUs } from "./touchWithUs";
const useStyles = makeStyles(theme => ({
  nested: {
    paddingLeft: theme.spacing(4)
  }
}));

export default function MenuList(props) {
  const direction = props.direction;
  const classes = useStyles();
  const [open, setOpen] = React.useState(false);

  const handleClick = () => {
    setOpen(!open);
  };

  return (
    <List
      component="nav"
      aria-labelledby="nested-list-subheader"
      className={classes.root}
    >
      {direction === "left" && (
        <div className="left-menu-top">
          <ListItem button>
            <NavLink activeClassName="active-menu" to="/signin">
              <ListItemText primary="Log in" />
            </NavLink>
          </ListItem>
          <ListItem button>
            <NavLink activeClassName="active-menu" to="/signup">
              <ListItemText primary="Sign Up" />
            </NavLink>
          </ListItem>

          {/*
         <ListItem className="sign-up-menu" button onClick={handleClick}>
            <ListItemText primary="Sign up" />
         { open ? <img src={arrowGreyDown} alt="icon" className="rotated"/> : <img src={arrowGreyDown} alt="icon" className="downArrowCo"/>}

          </ListItem>
            <Collapse in={open} timeout="auto" unmountOnExit className="sub-menu">
                <List component="div" disablePadding>
                    <ListItem button className={classes.nested}>
                        <ListItemText primary="Customer" />
                    </ListItem>
                    <ListItem button className={classes.nested}>
                        <ListItemText primary="Salon Admin" />
                    </ListItem>
                    <ListItem button className={classes.nested}>
                        <ListItemText primary="Hair Stylist" />
                    </ListItem>
                </List>
            </Collapse>
            */}

          <ListItem button>
            <NavLink activeClassName="active-menu" to="/hair-style-listing">
              <ListItemText primary="Hair Care Products" />
            </NavLink>
          </ListItem>
          <ListItem button className="border-none">
            <NavLink activeClassName="active-menu" to="/list-your-salon">
              <ListItemText primary="List your salon" />
            </NavLink>
          </ListItem>
          <TouchWithUs section="top" />
        </div>
      )}
      {direction === "right" && (
        <div>
          <ListItem button>
            <ListItemText primary="My Profile" />
          </ListItem>
          <ListItem button>
            <ListItemText primary="Change Password" />
          </ListItem>
          <ListItem button>
            <ListItemText primary="My Order" />
          </ListItem>
          <ListItem button>
            <ListItemText primary="Wishlist" />
          </ListItem>
        </div>
      )}
    </List>
  );
}
