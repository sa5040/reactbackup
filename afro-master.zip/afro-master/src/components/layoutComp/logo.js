import React from "react";
import Grid from "@material-ui/core/Grid";
import logoWhite from "../../assets/logoWhite.png";
export const Logo = () => {
  return (
    <Grid item xs={6}>
      <div className="logo">
        <img src={logoWhite} alt="logo" />
      </div>
    </Grid>
  );
};
