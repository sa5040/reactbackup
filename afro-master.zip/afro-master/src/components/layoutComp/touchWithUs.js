import React from "react";
import Fb from "../../assets/icon/Fb.png";
import GooglePlus from "../../assets/icon/GooglePlus.png";
import Instagram from "../../assets/icon/Instagram.png";
import Twitter from "../../assets/icon/Twitter.png";
import Email from "../../assets/icon/Email.png";

import fbBlack from "../../assets/icon/fbBlack.png";
import googlePlusBlack from "../../assets/icon/googlePlusBlack.png";
import instagramBlack from "../../assets/icon/instagramBlack.png";
import twitterBlack from "../../assets/icon/twitterBlack.png";
import { NavLink } from "react-router-dom";
export const TouchWithUs = props => {
  const section = props.section;
  return (
    <>
      {section === "footer" && (
        <ul className="social-icon">
          <li>
            <NavLink to="/signin">
              <img src={Fb} alt="facebook-icon" />
            </NavLink>
          </li>
          <li>
            <NavLink to="/signin">
              <img src={GooglePlus} alt="google-plus-icon" />
            </NavLink>
          </li>
          <li>
            <NavLink to="/signin">
              <img src={Twitter} alt="twitter-icon" />
            </NavLink>
          </li>
          <li>
            <NavLink to="/signin">
              <img src={Instagram} alt="instagram-icon" />
            </NavLink>
          </li>
          <li>
            <NavLink to="/signin">
              <img src={Email} alt="email-icon" />
            </NavLink>
          </li>
        </ul>
      )}
      {section === "top" && (
        <ul className="social-icon-mobile">
          <li>
            <NavLink to="/signin">
              <img src={fbBlack} alt="facebook-icon" />
            </NavLink>
          </li>
          <li>
            <NavLink to="/signin">
              <img src={googlePlusBlack} alt="google-plus-icon" />
            </NavLink>
          </li>
          <li>
            <NavLink to="/signin">
              <img src={twitterBlack} alt="twitter-icon" />
            </NavLink>
          </li>
          <li>
            <NavLink to="/signin">
              <img src={instagramBlack} alt="instagram-icon" />
            </NavLink>
          </li>
        </ul>
      )}

      <div className="touch-with-us-top">
        <div className="email">Email: hello@afrohair.com</div>
        <div className="mobile">Call Us: +44 - 807443233</div>
      </div>
    </>
  );
};
