import React from "react";
import { NavLink } from "react-router-dom";
import { Logo } from "./logo";
import { Container, makeStyles, Grid } from "@material-ui/core";
import { TouchWithUs } from "./touchWithUs";
const useStyles = makeStyles(theme => ({
  root: {
    [theme.breakpoints.down("sm")]: {
      "& .container": {
        paddingLeft: "20px"
      },
      "& .logo img": {
        width: "101px !important"
      },
      "& li": {
        fontsSize: "13px !important"
      },
      "& .social-icon li": {
        marginLeft: "15px"
      },
      "& .social-icon li:frist": {
        marginLeft: "0px !important"
      },
      "& h3": {
        fontSize: "14px !important"
      }
    }
  }
}));

export const Footer = () => {
  const classes = useStyles();
  return (
    <>
      <section className={`section section-footer ${classes.root}`}>
        <Container className="container">
          <Grid container direction="row" justify="center">
            <Grid item xs={12} md={3} lg={3}>
              <div className="copyright">
                <div className="row">
                  <Logo />
                </div>
                <div className="text">
                  Copyright © 2020
                  <br />
                  All Rights Reserved
                </div>
              </div>
            </Grid>

            <Grid item xs={6} md={3} lg={3}>
              <div className="company">
                <h3>COMPANY</h3>
                <ul>
                  <li>
                    <NavLink to="/signin">Login</NavLink>
                  </li>
                  <li>
                    <NavLink to="/signup">Sign Up</NavLink>
                  </li>
                  <li>
                    <NavLink to="/signup">List Your Salon</NavLink>
                  </li>
                  <li>
                    <NavLink to="/signup">About Us</NavLink>
                  </li>
                  <li>
                    <NavLink to="/signup">Hair Care Product</NavLink>
                  </li>
                </ul>
              </div>
            </Grid>

            <Grid item xs={6} md={3} lg={3}>
              <div className="more-link">
                <h3>MORE LINKS</h3>
                <ul>
                  <li>
                    <NavLink to="/signin">Careers</NavLink>
                  </li>
                  <li>
                    <NavLink to="/signin">Terms of use</NavLink>
                  </li>
                  <li>
                    <NavLink to="/signin">Privacy Policy</NavLink>
                  </li>
                  <li>
                    <NavLink to="/signin">Customer Service</NavLink>
                  </li>
                  <li>
                    <NavLink to="/signin">Corporate Contacts</NavLink>
                  </li>
                </ul>
              </div>
            </Grid>

            <Grid item xs={12} md={3} lg={3}>
              <div className="touch-with-us">
                <h3> MEDIA</h3>
                <TouchWithUs section="footer" />
              </div>
            </Grid>
          </Grid>
        </Container>
      </section>
    </>
  );
};
