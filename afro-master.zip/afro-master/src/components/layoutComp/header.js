import React from "react";
import {
  Container,
  Box,
  Grid,
  makeStyles,
  AppBar,
  Toolbar,
  Hidden
} from "@material-ui/core";
import { useLocation } from "react-router-dom";
import { Navs } from "./navs";
import { Logo } from "./logo";
import DrawerMenu from "../common/drawer/drawerMenu";

const useStyles = makeStyles(theme => ({
  root: {
    "& .mobile-nav": {
      background: "none",
      top: "10px",
      boxShadow: "none"
    },
    "& .small-header-mobile": {
      background: "#000",
      height: "64px",
      paddingTop: "6px",
      top: "0px"
    },
    "& .user-profile-menu": {
      textAlign: "right",
      position: "relative",
      right: "-10px"
    },
    "& .menu-list": {
      position: "relative"
    },
    "& .drawer-position": {
      position: "relative"
    },
    [theme.breakpoints.down("sm")]: {
      "& .logo img": {
        width: "80px"
      }
    }
  }
}));

export const Header = () => {
  const location = useLocation();
  const HeaderOption = () => {
    switch (location.pathname) {
      case "/":
        return { header: true, class: "" };
      case "/hair-style-listing":
        return {
          header: true,
          class: "header-small",
          mobileNav: "small-header-mobile"
        };

      default:
        return { header: true, class: "", mobileNav: "" };
    }
  };
  const MenuOption = HeaderOption();
  const classes = useStyles();
  return (
    <>
      <div className={classes.root}>
        <Hidden only={["sm", "xs"]}>
          {MenuOption.header && (
            <header className={`fixed-top-nav ${MenuOption.class}`}>
              <Container
                maxWidth="lg"
                direction="row"
                className="top-header-section"
                justify="center"
              >
                <Box display="flex">
                  <Grid item xs={6}>
                    <Logo />
                  </Grid>
                  <Grid item xs={6}>
                    <Navs />
                  </Grid>
                </Box>
              </Container>
            </header>
          )}
        </Hidden>
        <Hidden only={["lg", "md"]}>
          <AppBar
            position="absolute"
            className={`mobile-nav ${MenuOption.mobileNav} `}
          >
            <Toolbar>
              <Grid item xs={2} className="menu-list">
                <DrawerMenu direction="left" section="menu" />
              </Grid>
              <Grid item xs={7}>
                <Logo />
              </Grid>
              <Grid item xs={3} className="user-profile-menu">
                <DrawerMenu direction="right" section="menu" />
              </Grid>
            </Toolbar>
          </AppBar>
        </Hidden>
      </div>
    </>
  );
};
