import React from "react";
import { Grid, Box } from "@material-ui/core";
import { FormButton } from "../formComp/FormButton";
import { NavLink } from "react-router-dom";
export const Navs = () => {
  return (
    <>
      <Grid item xs={12} className="menu-section">
        <Box display="flex" justifyContent="flex-end">
          <ul>
            <li>
              <NavLink to="/signin">Hair Care Product</NavLink>
            </li>
            <li>
              <NavLink to="/signin">Login</NavLink>
            </li>
            <li className="sign-up sign-up-drop-down">
              <NavLink to="/signup">Sign Up</NavLink>
            </li>
            <li>
              <NavLink to="/list-your-salon">
                <FormButton
                  type="button"
                  classs="list-your-salon"
                  value="List Your Salon"
                />
              </NavLink>
            </li>
          </ul>
        </Box>
      </Grid>
    </>
  );
};
