import React from "react";
import { Tooltip, ClickAwayListener, Button } from "@material-ui/core";

export const ClicksTooltip = props => {
  const { customClass, classs, icon, buttonText } = props;
  const [open, setOpen] = React.useState(false);

  const handleTooltipClose = () => {
    setOpen(false);
  };

  const handleTooltipOpen = () => {
    setOpen(true);
  };

  return (
    <ClickAwayListener onClickAway={handleTooltipClose}>
      <div className={`block-elemnt-s ${customClass}`}>
        <Tooltip
          arrow
          interactive={true}
          PopperProps={{
            disablePortal: true
          }}
          onClose={handleTooltipClose}
          open={open}
          disableFocusListener
          disableHoverListener
          disableTouchListener
          title={props.children}
        >
          <Button
            onClick={handleTooltipOpen}
            className={classs}
            variant="outlined"
            startIcon={icon}
          >
            {buttonText}
          </Button>
        </Tooltip>
      </div>
    </ClickAwayListener>
  );
};
