import React from "react";
import { Tooltip } from "@material-ui/core";
import tooltipDownArrow from "../../../assets/icon/tooltipDownArrow.png";

export const HoverTooltip = props => {
  return (
    <div className="booking-grid-tooltip">
      <Tooltip
        arrow
        interactive={true}
        PopperProps={{
          disablePortal: true
        }}
        title={props.children}
      >
        <div>
          <span className={props.classes}>
            {props.text} <img src={tooltipDownArrow} alt="icon" />
          </span>
        </div>
      </Tooltip>
    </div>
  );
};
