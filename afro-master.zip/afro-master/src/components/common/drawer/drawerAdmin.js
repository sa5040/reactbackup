import React from "react";
import { Drawer } from "@material-ui/core";
import close from "../../../assets/icon/close.png";
import { FormButton } from "../../formComp/FormButton";

export const DrawerAdmin = props => {
  const { direction } = props;
  const [state, setState] = React.useState({
    left: false,
    right: false,
    bottom: false
  });
  const toggleDrawer = (anchor, open) => event => {
    if (
      event.type === "keydown" &&
      (event.key === "Tab" || event.key === "Shift")
    ) {
      return;
    }
    setState({ ...state, [anchor]: open });
  };

  return (
    <React.Fragment key={direction}>
      {/*
           Below Param Need to pass to  this component
             direction left| Right|bottom
             title 
             buttonText 
             classs
             contain
        */}

      <FormButton
        startIcon={props.icon}
        onClick={toggleDrawer(direction, true)}
        value={props.buttonText}
        classs={props.classs}
      />

      <Drawer
        className={props.drawerClass}
        anchor={direction}
        open={state[direction]}
        onClose={toggleDrawer(direction, false)}
      >
        <div className="top-section-drawer">
          <div className="title">
            {props.title}
            {props.subTitle && (
              <span className="sub-title">{props.subTitle}</span>
            )}
          </div>

          <img
            className="close-icon"
            src={close}
            alt="close icon"
            onClick={toggleDrawer(direction, false)}
          />
        </div>
        {props.children}
      </Drawer>
    </React.Fragment>
  );
};
