import React from "react";
import { Drawer } from "@material-ui/core";
import { FormButton } from "../../formComp/FormButton";
import { BookingStep } from "../../bookAppointment/bookingSteps";
import { SalonDetails } from "../../bookAppointment/salonDetails/salonDetails";

export const DrawerBooking = props => {
  const direction = "right";
  const [state, setState] = React.useState({
    left: false,
    right: false
  });
  const toggleDrawer = (anchor, open) => event => {
    if (
      event.type === "keydown" &&
      (event.key === "Tab" || event.key === "Shift")
    ) {
      return;
    }
    setState({ ...state, [anchor]: open });
  };

  return (
    <React.Fragment key={direction}>
      {/*
           Below Param Need to pass to  this component
             direction left| Right
             title 
             buttonText 
             classs
             contain
          
          */}

      <FormButton
        startIcon={props.icon}
        onClick={toggleDrawer(direction, true)}
        value={props.buttonText}
        classs={props.classs}
      />

      <Drawer
        anchor={direction}
        open={state[direction]}
        onClose={toggleDrawer(direction, false)}
      >
        <div>
          <SalonDetails />
          {/*
               <BookingStep toggleDrawer={toggleDrawer} />
               */}
        </div>
      </Drawer>
    </React.Fragment>
  );
};
