import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Drawer from "@material-ui/core/Drawer";
import Button from "@material-ui/core/Button";

import MenuList from "../../layoutComp/menuList";
import { BookAppointment } from "../../bookAppointment/bookAppointment";

import menuNav from "../../../assets/icon/menuNav.png";
import menu from "../../../assets/icon/menu.png";
import close from "../../../assets/icon/close.png";

const useStyles = makeStyles({
  list: {
    width: 250
  },
  fullList: {
    width: "auto"
  },
  toggolebutton: {
    padding: "0",
    position: "relative",
    left: "-4px",
    top: "-4px"
  },
  closeIcon: {
    "min-width": "240px",
    padding: "28px 0px 0px 20px"
  }
});

export default function DrawerMenu(props) {
  const classes = useStyles();
  const { direction, section } = props;
  const [state, setState] = React.useState({
    left: false,
    right: false
  });
  const toggleDrawer = (anchor, open) => event => {
    if (
      event.type === "keydown" &&
      (event.key === "Tab" || event.key === "Shift")
    ) {
      return;
    }
    setState({ ...state, [anchor]: open });
  };

  const list = () => (
    <div>
      <div className={classes.closeIcon}>
        <img
          src={close}
          alt="close icon"
          onClick={toggleDrawer(direction, false)}
        />
      </div>
      <MenuList direction={direction} />
    </div>
  );

  return (
    <div>
      <React.Fragment key={direction}>
        {section === "menu" && (
          <Button
            className={classes.toggolebutton}
            onClick={toggleDrawer(direction, true)}
          >
            <img src={direction === "left" ? menuNav : menu} alt="nav" />
          </Button>
        )}

        {section === "desktop" && (
          <Button
            variant="outlined"
            className="button-book-an-appointment"
            onClick={toggleDrawer(direction, true)}
          >
            Book an Appointment
          </Button>
        )}

        <Drawer
          anchor={direction}
          open={state[direction]}
          onClose={toggleDrawer(direction, false)}
        >
          {section === "menu" ? list(direction) : <BookAppointment />}
        </Drawer>
      </React.Fragment>
    </div>
  );
}
