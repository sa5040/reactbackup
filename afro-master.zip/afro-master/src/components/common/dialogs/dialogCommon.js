import React from "react";
import { withStyles } from "@material-ui/core/styles";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import MuiDialogTitle from "@material-ui/core/DialogTitle";
import MuiDialogContent from "@material-ui/core/DialogContent";
import IconButton from "@material-ui/core/IconButton";
import CloseIcon from "@material-ui/icons/Close";

const styles = theme => ({
  root: {
    margin: 0
  },
  closeButton: {
    position: "absolute",
    right: theme.spacing(1),
    top: theme.spacing(1),
    color: theme.palette.grey[500]
  }
});

const DialogTitle = withStyles(styles)(props => {
  const { children, classes, onClose, ...other } = props;
  return (
    <MuiDialogTitle disableTypography className={classes.root} {...other}>
      <h6 className="title">{children}</h6>
      {onClose ? (
        <IconButton
          aria-label="close"
          className={classes.closeButton}
          onClick={onClose}
        >
          <CloseIcon />
        </IconButton>
      ) : null}
    </MuiDialogTitle>
  );
});

const DialogContent = withStyles(theme => ({
  root: {
    padding: "0px 16px 16px 21px"
  }
}))(MuiDialogContent);

export const DialogCommon = props => {
  const [open, setOpen] = React.useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };

  return (
    <>
      {props.section === "button" && (
        <Button
          className="sort-by-button-xs"
          variant="outlined"
          color="primary"
          onClick={handleClickOpen}
          endIcon={props.icon}
        >
          Sort by
        </Button>
      )}

      {props.section === "span" && (
        <span onClick={handleClickOpen}>
          {props.text} {props.icon}
        </span>
      )}

      <Dialog
        className={props.customClass}
        onClose={handleClose}
        aria-labelledby="customized-dialog-title"
        open={open}
      >
        <DialogTitle onClose={handleClose}>{props.title}</DialogTitle>

        <DialogContent>{props.children}</DialogContent>
      </Dialog>
    </>
  );
};
