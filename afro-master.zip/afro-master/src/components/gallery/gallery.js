import React from "react";

import {
  Grid,
  makeStyles,
  Card,
  CardContent,
  CardMedia
} from "@material-ui/core";

import "./gallery.scss";

import { ThumbUp } from "@material-ui/icons";
import serviceOne from "../../assets/service/serviceOne.png";
import serviceTwo from "../../assets/service/serviceTwo.png";
import serviceThree from "../../assets/service/serviceThree.png";

import serviceFour from "../../assets/service/serviceFour.png";
import serviceFive from "../../assets/service/serviceFive.png";
import serviceSix from "../../assets/service/serviceSix.png";

const useStyles = makeStyles(theme => ({
  root: {
    [theme.breakpoints.down("sm")]: {
      width: "100%",
      padding: "7px",
      "& .profile-card": {
        maxWidth: "160px",
        minWidth: "160px"
      },
      "& .select-style-grid": {
        width: "157px",
        height: "254px",
        margin: "6px"
      }
    }
  },
  media: {
    height: 180
  },
  card: {
    maxWidth: 180,
    minWidth: 180,
    padding: "0px"
  }
}));

export const Gallery = () => {
  const StyleProfile = [
    {
      id: 1,
      category: "Hair Cutting",
      service: [
        {
          id: "1",
          name: "Adam Denisov",
          price: "$102.0",
          like: "345k",
          image: serviceOne
        },
        {
          id: "2",
          name: "Farrokh Rastegar",
          price: "$102.0",
          like: "345k",
          image: serviceTwo
        },
        {
          id: "3",
          name: "Paromita Haque",
          price: "$102.0",
          like: "345k",
          image: serviceThree
        }
      ]
    },
    {
      id: 2,
      category: "Nail Treatment",
      service: [
        {
          id: "1",
          name: "Adam Denisov",
          price: "$102.0",
          like: "345k",
          image: serviceFour
        },
        {
          id: "2",
          name: "Farrokh Rastegar",
          price: "$102.0",
          like: "345k",
          image: serviceFive
        },
        {
          id: "3",
          name: "Paromita Haque",
          price: "$102.0",
          like: "345k",
          image: serviceSix
        }
      ]
    }
  ];

  const classes = useStyles();
  return (
    <div className={`gallery-section ${classes.root}`}>
      <Grid container direction="row">
        {StyleProfile.map(items => (
          <div key={items.id}>
            <div className="category-name"> {items.category}</div>
            <div className="select-style-item">
              {items.service.map(item => (
                <div className="select-style-grid" key={item.id}>
                  <Card className={`${classes.card} profile-card`}>
                    <CardMedia
                      className={classes.media}
                      image={item.image}
                      title="map"
                    />
                    <CardContent>
                      <div className="image-text">
                        <div className="botton-text">
                          <span className="like-icon">
                            {" "}
                            <ThumbUp />{" "}
                          </span>{" "}
                          {item.like}
                        </div>
                      </div>
                      <div className="select-style-name">{item.name}</div>
                      <div className="select-style-price">
                        <div className="price"> {item.price}</div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              ))}
            </div>
          </div>
        ))}
      </Grid>
    </div>
  );
};
