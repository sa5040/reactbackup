import React from "react";
import {
  makeStyles,
  Box,
  Stepper,
  Step,
  StepButton,
  Button,
  Hidden
} from "@material-ui/core";
import { ArrowForward, ArrowBack } from "@material-ui/icons";
import { FormButton } from "../formComp/FormButton";
import { ChooseService } from "./ChooseService";
import { SelectStyle } from "./selectStyle";
import { SelectDateTime } from "./selectDateTime";
import { ConfirmYourOrder } from "./confirmYourOrder";
import close from "../../assets/icon/close.png";

import "./bookAppointment.scss";
const useStyles = makeStyles(theme => ({
  root: {
    [theme.breakpoints.down("xs")]: {
      width: "100%",
      maxWidth: "610px",
      padding: "10px 0px",
      "& .bottom-button-section": {
        right: "15px !important"
      },
      "& .button-next": {
        width: "93%"
      }
    }
  }
}));

function getSteps() {
  return ["Select Service", "Select Style", "Date & Time"];
}

function getStepContent(step) {
  switch (step) {
    case 0:
      return <ChooseService />;
    case 1:
      return <SelectStyle />;
    case 2:
      return <SelectDateTime />;
    default:
      return "Unknown step";
  }
}

export const BookingStep = props => {
  const steperComplete = true;
  const classes = useStyles();
  const [activeStep, setActiveStep] = React.useState(0);
  const [completed, setCompleted] = React.useState({});
  const steps = getSteps();

  const totalSteps = () => {
    return steps.length;
  };

  const completedSteps = () => {
    return Object.keys(completed).length;
  };

  const isLastStep = () => {
    return activeStep === totalSteps() - 1;
  };

  const allStepsCompleted = () => {
    return completedSteps() === totalSteps();
  };

  const handleNext = () => {
    const newActiveStep =
      isLastStep() && !allStepsCompleted()
        ? // It's the last step, but not all steps have been completed,
          // find the first step that has been completed
          steps.findIndex((step, i) => !(i in completed))
        : activeStep + 1;
    setActiveStep(newActiveStep);
  };

  const handleBack = () => {
    setActiveStep(prevActiveStep => prevActiveStep - 1);
  };

  const handleStep = step => () => {
    setActiveStep(step);
  };

  const handleComplete = () => {
    const newCompleted = completed;
    newCompleted[activeStep] = true;
    setCompleted(newCompleted);
    handleNext();
  };

  const handleReset = () => {
    setActiveStep(0);
    setCompleted({});
  };

  return (
    <div className={`${classes.root} section-book-an-appointment`}>
      <div className="section-drawer">
        <Box width="100%" display="flex">
          <Box width="80%">
            {activeStep > 0 && (
              <div className="step-back">
                <Button
                  startIcon={<ArrowBack />}
                  disabled={activeStep === 0}
                  onClick={handleBack}
                  className="back-button"
                >
                  Back
                </Button>
              </div>
            )}
            <div className="title">
              {" "}
              Book an Appointment
              <span className="sub-title">for Hair & Skin Clinic</span>
            </div>
          </Box>

          <Box width="20%" className="close-icon-sec">
            <img
              className="close-icon"
              src={close}
              alt="close icon"
              onClick={props.toggleDrawer("right", false)}
            />
          </Box>
        </Box>
      </div>

      {steperComplete && (
        <div>
          <Hidden only={["sm", "xs"]}>
            <Stepper nonLinear activeStep={activeStep}>
              {steps.map((label, index) => (
                <Step key={label}>
                  <StepButton
                    onClick={handleStep(index)}
                    completed={completed[index]}
                  >
                    {label}
                  </StepButton>
                </Step>
              ))}
            </Stepper>
          </Hidden>
          <div className="step-contain">{getStepContent(activeStep)}</div>
        </div>
      )}
      {!steperComplete && <ConfirmYourOrder />}

      <div className="bottom-button-section">
        <FormButton
          endIcon={<ArrowForward />}
          onClick={handleNext}
          value="Proceed to Next"
          classs="black-button button-next"
        />
      </div>
    </div>
  );
};
