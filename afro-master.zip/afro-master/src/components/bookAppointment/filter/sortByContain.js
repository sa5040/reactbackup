import React from "react";
import { FormControlLabel, Radio, RadioGroup } from "@material-ui/core";

export const SortByContain = props => {
  const [value, setValue] = React.useState("recommended");

  const handleChange = event => {
    setValue(event.target.value);
  };

  const sortRecommended = [
    { id: 1, label: "Recommended", value: "recommended" },
    { id: 2, label: "Highest Rated", value: "highestRated" },
    { id: 3, label: "Lowest Price", value: "lowestPrice" },
    { id: 4, label: "Highest Price", value: "highestPrice" },
    { id: 5, label: "Discount", value: "discount" }
  ];

  return (
    <div className="sort-by-radio">
      <RadioGroup
        aria-label="sortBy"
        name="sortBy"
        value={value}
        onChange={handleChange}
      >
        {sortRecommended.map(item => (
          <FormControlLabel
            key={item.id}
            value={item.value}
            control={<Radio />}
            label={item.label}
          />
        ))}
      </RadioGroup>
    </div>
  );
};
