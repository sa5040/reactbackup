import React from "react";
import { Button, Grid } from "@material-ui/core";
import { PriceSlider } from "./priceSlider";
import { SelectService } from "../../salonAdmin/selectService";
import "./filter.scss";
export const FilterContain = props => {
  return (
    <div className="filter-common-section">
      <Grid item xs={12} className="grid-checkbox">
        <div className="Salon-services-title">Salon services</div>
        <SelectService />
        <Grid item xs={12} className="price-filter-section">
          <div className="budget-range-title">Budget Range ( in USD )</div>
          <div className="budget-range">
            <PriceSlider />
          </div>
        </Grid>
      </Grid>

      <Grid
        container
        direction="row"
        justify="center"
        className="bottom-filter-section"
      >
        <Grid item xs={6} className="clear-all">
          <Button variant="outlined" color="primary">
            Clear All
          </Button>
        </Grid>
        <Grid item xs={6} className="apply-filter">
          <Button variant="contained" color="primary">
            Apply Filter
          </Button>
        </Grid>
      </Grid>
    </div>
  );
};
