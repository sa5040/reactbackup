import React from "react";
import { makeStyles, Grid, AppBar } from "@material-ui/core";
import { FilterContain } from "./filterContain";
import { SortByContain } from "./sortByContain";

import filter from "../../../assets/icon/filter.png";
import uncheck from "../../../assets/icon/uncheck.png";
import "../bookAppointment.scss";
import { DrawerAdmin } from "../../common/drawer/drawerAdmin";
import { DialogCommon } from "../../common/dialogs/dialogCommon";

const useStyles = makeStyles(theme => ({
  appBar: {
    top: "auto",
    bottom: "20px",
    height: "50px",
    background: "none",
    boxShadow: "none"
  }
}));

export const BottomSection = () => {
  const classes = useStyles();
  return (
    <React.Fragment>
      <AppBar
        position="fixed"
        color="primary"
        className={`${classes.appBar} section-bottom-filter`}
      >
        <Grid
          container
          alignItems="center"
          className={`${classes.root} filter-grid-xs`}
        >
          <DrawerAdmin
            direction="bottom"
            title="Filters"
            classs="filter-button-xs"
            icon={<img src={filter} alt="Filters icon" />}
            buttonText="Filters"
            drawerClass="bottom-drawer"
          >
            <div className="filter-contain">
              <FilterContain />
            </div>
          </DrawerAdmin>
          <DialogCommon
            section="button"
            title="Sort By"
            customClass="dialog-width"
            icon={<img src={uncheck} alt="Sort By icon" />}
          >
            <SortByContain />
          </DialogCommon>
        </Grid>
      </AppBar>
    </React.Fragment>
  );
};
