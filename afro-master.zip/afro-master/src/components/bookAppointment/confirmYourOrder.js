import React from "react";
import { ApplyCoupon } from "./applyCoupon";

export const ConfirmYourOrder = () => {
  const products = [
    { id: 1, name: "Adam Denisov", price: "$109.00" },
    { id: 2, name: "Kwak Seong-Min", price: "$39.00" }
  ];

  return (
    <>
      <div className="confirm-your-order">
        <div className="main-title">Confirm Your Order</div>
        <div className="product-list-section">
          <ul className="product-added">
            {products.map((item, i) => (
              <li
                key={item.id}
                className={`${products.length - 1 === i ? "lastitem" : ""}`}
              >
                <div className="product-name"> {item.name} </div>
                <div className="product-price">{item.price} </div>
              </li>
            ))}
          </ul>
        </div>

        <div className="apply-coupon-section">
          <ApplyCoupon />
        </div>

        <div className="bill-details">
          <div className="bill-title">Bill Details</div>
          <ul>
            <li>
              <div className="item-total"> Item Total </div>
              <div className="price"> $148.00 </div>
            </li>
            <li>
              <div className="taxes-and-charges"> Taxes and charges </div>
              <div className="price"> $10.00</div>
            </li>
            <li>
              <div className="total-amount">Total amount to pay </div>
              <div className="total-price"> $158.00</div>
            </li>
          </ul>
        </div>
      </div>
    </>
  );
};
