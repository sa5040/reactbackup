import React from "react";
import { makeStyles } from "@material-ui/core";
import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";

const useStyles = makeStyles(theme => ({
  root: {
    [theme.breakpoints.down("xs")]: {
      "& .react-multi-carousel-list": {
        maxWidth: "320px"
      },
      "& .react-multiple-carousel__arrow--right, .react-multiple-carousel__arrow--left": {
        display: "none"
      },
      "& .date-container": {
        margin: "0 20px 0px 7px !important"
      }
    }
  }
}));

export const OurLocation = props => {
  const classes = useStyles();

  const responsive = {
    desktop: {
      breakpoint: { max: 3000, min: 1024 },
      items: 2,
      slidesToSlide: 2
    },
    tablet: {
      breakpoint: { max: 1024, min: 464 },
      items: 2
    },
    mobile: {
      breakpoint: { max: 364, min: 350 },
      items: 2
    }
  };

  return (
    <>
      <div className={`${classes.root} our-location`}>
        <div className="date-container">
          <Carousel responsive={responsive}>
            {props.location.map((item, index) => (
              <div className="location" key={index}>
                {item.address}
              </div>
            ))}
          </Carousel>
        </div>
      </div>
    </>
  );
};
