import React from "react";
import {
  Grid,
  Card,
  CardContent,
  Button,
  makeStyles,
  Hidden
} from "@material-ui/core";
import Grade from "@material-ui/icons/Grade";

import { FormButton } from "../../../components/formComp/FormButton";
import galleryIcon from "../../../assets/icon/galleryIcon.png";
import bookAppointment from "../../../assets/icon/bookAppointment.png";

export const Salon = props => {
  return (
    <Grid item xs={12} lg={12}>
      <Card className="card common-sec ">
        <CardContent className="card-body">
          {props.salonDetails.map(item => (
            <Grid
              direction="row"
              container
              key={item.id}
              className="container-list"
            >
              <Grid item xs={12} sm={8} lg={8} className="grid-details">
                <Grid item xs={12} direction="row" container>
                  <Grid xs={12} lg={12} item className="title">
                    <h1> {item.name}</h1>
                  </Grid>
                </Grid>

                <Grid item xs={12} className="grid-address">
                  <p> {item.address} </p>
                </Grid>
                <Grid item xs={12} className="tag-button">
                  {item.tags.map((tag, index) => (
                    <div key={tag.id}>
                      {index <= 2 && (
                        <Button
                          className={`${index === 0 ? "frist-button" : ""}`}
                          variant="outlined"
                        >
                          {tag.label}
                        </Button>
                      )}
                    </div>
                  ))}
                  <Button variant="outlined">{item.tags.length - 4} +</Button>
                </Grid>
                <Grid item xs={12} className="section-contact">
                  <div className="phone">
                    <span className="title">
                      Phone No<i>:</i>
                    </span>
                    {item.phone.map((phone, index) => (
                      <span className="contain" key={index}>
                        {phone}
                      </span>
                    ))}
                  </div>
                  <div className="email">
                    <span className="title">
                      Email<i>:</i>
                    </span>
                    <span className="contain">{item.email} </span>
                  </div>
                </Grid>

                <Grid item xs={12} className="action-grid">
                  <FormButton
                    classs="button-book-an-appointment"
                    value="Book an Appointment"
                    startIcon={<img src={bookAppointment} alt="icon" />}
                  />

                  <FormButton
                    classs="button-gallery"
                    value="Gallery"
                    startIcon={<img src={galleryIcon} alt="icon" />}
                  />
                </Grid>
              </Grid>
              <Grid item xs={12} sm={3} lg={3}>
                <img src={item.img} className="respnsive-img" alt="icon" />
              </Grid>
            </Grid>
          ))}
        </CardContent>
      </Card>
    </Grid>
  );
};
