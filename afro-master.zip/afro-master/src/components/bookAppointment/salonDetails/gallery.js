import React from "react";
import { makeStyles } from "@material-ui/core";
import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";

const useStyles = makeStyles(theme => ({
  root: {
    [theme.breakpoints.down("xs")]: {
      "& .react-multi-carousel-list": {
        maxWidth: "320px"
      },
      "& .react-multiple-carousel__arrow--right, .react-multiple-carousel__arrow--left": {
        display: "none"
      },
      "& .date-container": {
        margin: "0 20px 0px 7px !important"
      }
    }
  }
}));

export const Gallery = props => {
  const classes = useStyles();

  const responsive = {
    desktop: {
      breakpoint: { max: 3000, min: 1024 },
      items: 1
    },
    tablet: {
      breakpoint: { max: 1024, min: 464 },
      items: 1
    },
    mobile: {
      breakpoint: { max: 364, min: 350 },
      items: 1
    }
  };

  return (
    <>
      <div className={`${classes.root} salon-gallery`}>
        <div className="date-container">
          <Carousel responsive={responsive}>
            {props.images.map((item, index) => (
              <div className="img-gallery" key={index}>
                <img src={item} alt="gallery" />
              </div>
            ))}
          </Carousel>
        </div>
      </div>
    </>
  );
};
