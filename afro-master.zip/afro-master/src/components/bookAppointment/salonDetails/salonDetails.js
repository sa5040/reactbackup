import React from "react";
import { Salon } from "./salon";
import "./salonDetails.scss";
import { BookingTime } from "../bookingTime";
import { OurLocation } from "./ourLocation";
import { Gallery } from "./gallery";
import { SalonDetailsJson } from "../../../jsonserver/hairStyleListing";
export const SalonDetails = () => {
  return (
    <div className="hair-style-details">
      <Salon salonDetails={SalonDetailsJson} />
      <div>
        <div className="section-title">Open Hours</div>
        <BookingTime open={SalonDetailsJson[0].open} />
      </div>
      <div>
        <div className="section-title">Our Locations</div>
        <OurLocation location={SalonDetailsJson[0].locations} />
      </div>
      <div>
        <div className="section-title">Gallery</div>
        <Gallery images={SalonDetailsJson[0].gallery} />
      </div>
    </div>
  );
};
