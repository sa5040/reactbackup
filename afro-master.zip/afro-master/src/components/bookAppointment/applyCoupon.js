import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Paper from "@material-ui/core/Paper";
import offers from "../../assets/icon/offers.png";
import { FormButton } from "../formComp/FormButton";
import { InputField } from "../formComp/InputField";
const useStyles = makeStyles(theme => ({
  root: {
    padding: "2px 4px",
    display: "flex",
    alignItems: "center"
  },
  input: {
    marginLeft: theme.spacing(1),
    flex: 1
  },
  iconButton: {
    padding: 10
  },
  divider: {
    height: 28,
    margin: 4
  }
}));

export const ApplyCoupon = () => {
  const classes = useStyles();

  return (
    <Paper component="div" className={` ${classes.root} apply-code-grid`}>
      <img src={offers} alt="icon" className={classes.iconButton} />
      <InputField
        className="input-apply-code"
        placeholder="Have a Promocode/Coupon Code"
        inputProps={{ "aria-label": "Have a Promocode/Coupon Code" }}
      />

      <FormButton
        type="button"
        value="Apply Code"
        className={`${classes.iconButton} apply-code`}
      />
    </Paper>
  );
};
