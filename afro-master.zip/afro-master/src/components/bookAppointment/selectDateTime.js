import React from "react";
import { makeStyles } from "@material-ui/core";
import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";

const useStyles = makeStyles(theme => ({
  root: {
    [theme.breakpoints.down("xs")]: {
      "& .available-slots-section .dates": {
        width: "158px !important",
        height: "60px !important",
        margin: "7px !important"
      },
      "& .react-multi-carousel-list": {
        maxWidth: "320px"
      },
      "& .react-multiple-carousel__arrow--right, .react-multiple-carousel__arrow--left": {
        display: "none"
      },
      "& .date-container": {
        margin: "0 20px 0px 7px !important"
      }
    }
  }
}));

export const SelectDateTime = () => {
  const classes = useStyles();
  const dates = [
    { date: 22, days: "Today" },
    { date: 23, days: "Tomorrow" },
    { date: 24, days: "Tue" },
    { date: 25, days: "Wed" },
    { date: 26, days: "Fri" },
    { date: 27, days: "Fri" },
    { date: 28, days: "Fri" },
    { date: 29, days: "Fri" },
    { date: 30, days: "Fri" },
    { date: 31, days: "Fri" }
  ];

  const availableSlots = [
    {
      id: 1,
      service: "Hair Cutting",
      label: " Hair Cutting",
      times: [
        { time: "10:00 pm", booked: false, selected: true },
        { time: "11:00 pm", booked: true, selected: true },
        { time: "12:00 pm", booked: false, selected: false },
        { time: "1:00 pm", booked: false, selected: false },
        { time: "2:00 pm", booked: false, selected: false },
        { time: "3:00 pm", booked: false, selected: false }
      ]
    },
    {
      id: 2,
      service: " Nail Treatment",
      label: " Nail Treatment",
      times: [
        { time: "10:00 am", booked: false, selected: true },
        { time: "11:00 am", booked: true, selected: true },
        { time: "12:00 pm", booked: false, selected: false },
        { time: "1:00 pm", booked: false, selected: false },
        { time: "2:00 pm", booked: false, selected: false },
        { time: "3:00 pm", booked: false, selected: false }
      ]
    }
  ];

  const responsive = {
    desktop: {
      breakpoint: { max: 3000, min: 1024 },
      items: 6,
      slidesToSlide: 2
    },
    tablet: {
      breakpoint: { max: 1024, min: 464 },
      items: 4
    },
    mobile: {
      breakpoint: { max: 364, min: 350 },
      items: 4
    }
  };

  return (
    <>
      <div className={`${classes.root} section-date-time-select`}>
        <div className="main-title">Select the Date & Time</div>
        <div className="date-container">
          <Carousel responsive={responsive}>
            {dates.map(item => (
              <div className="date-time-grid" key={item.date}>
                <span className="date">{item.date}</span>
                <span className="days">{item.days}</span>
              </div>
            ))}
          </Carousel>
        </div>
        <div className="available-slots-section">
          {availableSlots.map(item => (
            <div key={item.id}>
              <div className="category">{item.label}</div>
              <div>
                {item.times.map(dates => (
                  <div
                    className={`dates ${
                      dates.booked ? "booked" : dates.selected ? "selected" : ""
                    }`}
                    key={dates.time}
                  >
                    {dates.time}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};
