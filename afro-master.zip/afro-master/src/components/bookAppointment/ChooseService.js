import React from "react";
import { Checkbox, makeStyles } from "@material-ui/core";

const useStyles = makeStyles(theme => ({
  root: {
    [theme.breakpoints.down("xs")]: {
      "& .select-service": {
        width: "114px !important",
        height: "54px !important",
        margin: "9px !important"
      }
    }
  }
}));

export const ChooseService = () => {
  const classes = useStyles();
  const [state, setState] = React.useState([
    { id: 10, name: "haircutting", label: "Hair cutting", value: false },
    { id: 2, name: "haircolouring", label: "Hair colouring", value: false },
    { id: 3, name: "hairstyling", label: "Hair styling", value: false },
    { id: 4, name: "hairwaxing", label: "Hair waxing", value: false },
    { id: 5, name: "nailtreatments", label: "Nail treatments", value: false }
  ]);

  const handleChange = (event, val) => {
    let newArray = state.map(item => {
      if (item.id === val.id) {
        item.value = event.target.checked;
        return item;
      } else {
        item.value = false;
        return item;
      }
    });

    setState(newArray);
  };

  return (
    <>
      <div className={`${classes.root} select-service-section`}>
        <div className="main-title">Select the services you interested in</div>
        <div className="main-sub-title">(you can select multiple services)</div>
        {state.map(item => (
          <div
            className={`select-service ${
              item.value === true ? "active-chk" : ""
            }`}
            key={`${item.id}${item.name}`}
          >
            <div className="title">{item.label}</div>
            <div className="chk">
              {" "}
              <Checkbox
                checked={item.value}
                onChange={e => handleChange(e, item)}
                name={item.name}
              />
            </div>
          </div>
        ))}
      </div>
    </>
  );
};
