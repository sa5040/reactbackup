import React from "react";
import "./bookAppointment.scss";
export const BookAppointment = () => {
  return (
    <div className="section-book-an-appointment">
      <h1> Book an Appointment </h1>
    </div>
  );
};
