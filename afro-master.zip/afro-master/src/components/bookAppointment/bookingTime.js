import React from "react";
import { ListItem, List } from "@material-ui/core";

export const BookingTime = props => {
  return (
    <div className="booking-grid">
      <List component="nav" className="Oval">
        {props.open.map(item => (
          <ListItem key={item.id}>
            <span></span> <span>{item.day} </span> <span>{item.time}</span>
          </ListItem>
        ))}
      </List>
    </div>
  );
};
