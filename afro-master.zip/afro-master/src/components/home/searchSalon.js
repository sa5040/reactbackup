import React from "react";
import { makeStyles } from "@material-ui/core";
import searchIcon from "../../assets/icon/searchIcon.png";
import { FormButton } from "../formComp/FormButton";
const useStyles = makeStyles(theme => ({
  root: {
    [theme.breakpoints.down("sm")]: {
      bottom: "-40px",
      "& .container-top": {
        width: "90% !important",
        "& .search-section": {
          height: "80px !important",
          "& .searchParam": {
            height: "78px !important",
            fontSize: "18px !important"
          },
          "& .search-action": {
            width: "auto !important",
            right: "0px",
            "& .button": {
              width: "64px !important",
              height: "64px",
              color: "#ffb63e",
              fontSize: "10px !important"
            },
            "& .search-icon": {
              left: "10px",
              width: "auto",
              top: " 9px"
            },
            "& .search-btn": {
              top: "-6px !important",
              right: "6px !important"
            }
          }
        }
      }
    }
  }
}));
export const SearchSalon = () => {
  const classes = useStyles();
  return (
    <div className={`section-home-search ${classes.root}`}>
      <div className="container-top">
        <div className="search-section">
          <div className="search-input">
            <input
              className="searchParam"
              type="text"
              placeholder="Enter Your Location"
              required
            />
          </div>
          <div className="search-action">
            <div className="search-icon">
              <img src={searchIcon} alt="search-icon" />
            </div>
            <div className="search-btn">
              <FormButton type="button" classs="button" value="Search" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
