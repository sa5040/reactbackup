import React from "react";
import { Container, Grid, makeStyles } from "@material-ui/core";
import { HairGallerySlide } from "./hairGallerySlide";
import { FormButton } from "../formComp/FormButton";
const useStyles = makeStyles(theme => ({
  root: {
    [theme.breakpoints.down("sm")]: {
      "&.section-create-own-gallery ": {
        padding: " 70px 20px 50px 0px",
        "& h3 ": {
          margin: "0",
          fontSize: "28px",
          width: "82%",
          lineHeight: "36px"
        },
        "& .button-create-yours-now": {
          width: "159px !important",
          height: "48px !important",
          fontSize: "14px !important",
          margin: "23px 0px 20px 0px"
        }
      }
    }
  }
}));

export const HairGallery = () => {
  const classes = useStyles();
  return (
    <section className={`section section-create-own-gallery ${classes.root}`}>
      <Container>
        <Grid container direction="row" justify="center">
          <Grid item xs={12} lg={5} className="desc">
            <p>HAIRDO GALLERY</p>
            <h3> Create your own hairdo gallery and share with your friends</h3>
            <FormButton
              type="button"
              classs="button-create-yours-now"
              value="Create Yours Now"
            />
          </Grid>
          <Grid item xs={12} lg={7}>
            <HairGallerySlide />
          </Grid>
        </Grid>
      </Container>
    </section>
  );
};
