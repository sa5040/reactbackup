import React from "react";
import { FormButton } from "../formComp/FormButton";
import { makeStyles } from "@material-ui/core";
const useStyles = makeStyles(theme => ({
  root: {
    [theme.breakpoints.down("sm")]: {
      "& .bg-cover-trafic": {
        backgroundImage: "none !important",
        height: "50vh",
        minHeight: " 350px",
        "& h3": {
          fontSize: "30px !important",
          padding: " 0 16px",
          margin: "0"
        },
        "& .bottom-text": {
          padding: "0 50px !important",
          fontSize: "16px !important"
        },
        "& .top-text": {
          fontSize: "14px !important",
          color: "#506d85 !important"
        },
        "& .button-start-now": {
          width: "159px !important",
          height: "48px !important",
          fontSize: "14px !important"
        }
      }
    }
  }
}));
export const IncreaseTraffic = () => {
  const classes = useStyles();
  return (
    <section className={`section section-increase-traffic ${classes.root}`}>
      <div className="bg-cover-trafic">
        <div className="bg-container">
          <p className="top-text">List your salon</p>
          <h3>Want to increase traffic to your salon?</h3>
          <p className="bottom-text">
            List your salon with us and establish your identity
          </p>
          <FormButton
            type="button"
            classs="button-start-now"
            value="Start Now"
          />
        </div>
      </div>
    </section>
  );
};
