import React from "react";
import galleryImgTwo from "../../assets/galleryImgTwo.png";
import galleryImgOne from "../../assets/galleryImgOne.png";
import { Grid, makeStyles } from "@material-ui/core";
import like from "../../assets/icon/like.png";
import views from "../../assets/icon/views.png";

import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";
const useStyles = makeStyles(theme => ({
  root: {
    [theme.breakpoints.down("sm")]: {
      "& .react-multi-carousel-item": {
        margin: "0px !important"
      },
      "& .w-100": {
        width: "100%"
      }
    }
  }
}));

export const HairGallerySlide = () => {
  const classes = useStyles();
  const responsive = {
    superLargeDesktop: {
      // the naming can be any, depends on you.
      breakpoint: { max: 4000, min: 3000 },
      items: 2
    },
    desktop: {
      breakpoint: { max: 3000, min: 1024 },
      items: 2
    },
    tablet: {
      breakpoint: { max: 1024, min: 464 },
      items: 1
    },
    mobile: {
      breakpoint: { max: 464, min: 0 },
      items: 1
    }
  };
  return (
    <div className={`carousel-section ${classes.root}`}>
      <Carousel responsive={responsive}>
        <Grid item xs={12}>
          <div className="item-top">
            <span className="round">ZW</span>
            <span className="title">Zenith Williams</span>
          </div>
          <img
            className="d-block w-100"
            src={galleryImgTwo}
            alt="First slide"
          />
          <div className="item-bottom">
            <div className="total-like">
              <img src={like} alt="like icon" />
              <p>235K</p>
            </div>
            <div className="total-view">
              <img src={views} alt="views icon" />
              <p> 678M </p>
            </div>
          </div>
        </Grid>
        <Grid item xs={12}>
          <div className="item-top">
            <span className="round">ZW</span>{" "}
            <span className="title">Noell Blue</span>
          </div>
          <img
            className="d-block w-100"
            src={galleryImgOne}
            alt="First slide"
          />
          <div className="item-bottom">
            <div className="total-like">
              <img src={like} alt="like icon" />
              <p>235K</p>
            </div>
            <div className="total-view">
              <img src={views} alt="views icon" />
              <p> 678M </p>
            </div>
          </div>
        </Grid>
        <Grid item xs={12}>
          <div className="item-top">
            <span className="round">ZW</span>{" "}
            <span className="title">Zenith Williams</span>
          </div>
          <img
            className="d-block w-100"
            src={galleryImgTwo}
            alt="First slide"
          />
          <div className="item-bottom">
            <div className="total-like">
              <img src={like} alt="like icon" />
              <p>235K</p>
            </div>
            <div className="total-view">
              <img src={views} alt="views icon" />
              <p> 678M </p>
            </div>
          </div>
        </Grid>
      </Carousel>
    </div>
  );
};
