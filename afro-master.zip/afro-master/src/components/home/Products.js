import React from "react";
import { Container, Grid, makeStyles } from "@material-ui/core";
import { ProductList } from "./productList";
import { FormButton } from "../formComp/FormButton";

const useStyles = makeStyles(theme => ({
  root: {
    [theme.breakpoints.down("sm")]: {
      padding: "30px 0px 50px 0px !important",
      "& .products-list-title": {
        margin: "20px 0px 10px 0px",
        textAlign: "left",
        "& li": {
          fontSize: "24px",
          marginLeft: "18px"
        }
      },
      "& .button-view-all-products": {
        width: "159px !important",
        height: "48px !important",
        fontSize: "14px !important"
      },
      "& .view-all-product": {
        marginTop: "30px !important"
      }
    }
  }
}));
export const Products = () => {
  const classes = useStyles();
  return (
    <section className={`section section-hair-care-product ${classes.root}`}>
      <Container>
        <h4>Hair Care Products</h4>
        <ul className="products-list-title">
          <li className="actice-section">Women</li>
          <li>Men</li>
          <li>Kids</li>
          <li>Accessories</li>
        </ul>
        <Grid item xs={12}>
          <ProductList />
          <div className="view-all-product">
            <FormButton
              type="button"
              classs="button-view-all-products btn-hover-effect"
              value="View All Products"
            />
          </div>
        </Grid>
      </Container>
    </section>
  );
};
