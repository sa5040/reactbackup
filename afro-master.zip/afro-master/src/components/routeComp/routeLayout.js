import React from "react";
import { Header } from '../layoutComp/header';
import { Footer}  from '../layoutComp/footer';

export const RouteLayout = (props) => {
  const { options } = props;
  return (
    <>
      { options.header &&  <Header />}
     
       {props.children}
     
      { options.footer &&  <Footer />}
    
     </>
  )
};
