import React from "react";
import { useHistory } from "react-router-dom";
import close from "../../assets/icon/close.png";
export const GoBackRoute = () => {
  let history = useHistory();
  const goBack = () => {
    history.goBack();
  };
  return (
    <div className="back-section">
      <img src={close} alt="close icon" onClick={goBack} />{" "}
    </div>
  );
};
