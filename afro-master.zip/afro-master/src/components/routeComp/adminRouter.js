import React from "react";
import { Switch, Route } from "react-router-dom";
import { Profile } from "../../container/salonAdmin/profile";
import { Appointment } from "../../container/salonAdmin/appointment";
import { Salon } from "../../container/salonAdmin/salon";
import { Services } from "../../container/salonAdmin/services";
import { Employee } from "../../container/salonAdmin/employee";
import { Finances } from "../../container/salonAdmin/finances";

export const AdminRouter = props => {
  const { path } = props;
  return (
    <Switch>
      <Route exact path={`${path}/profile`}>
        {" "}
        <Profile />{" "}
      </Route>
      <Route path={`${path}/salon`}>
        {" "}
        <Salon />{" "}
      </Route>
      <Route path={`${path}/services`}>
        {" "}
        <Services />
      </Route>
      <Route path={`${path}/employee`}>
        {" "}
        <Employee />
      </Route>
      <Route path={`${path}/appointment`}>
        <Appointment />
      </Route>
      <Route path={`${path}/finances`}>
        {" "}
        <Finances />
      </Route>
    </Switch>
  );
};
