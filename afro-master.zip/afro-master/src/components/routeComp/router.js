import React from "react";
import { Switch, Route, BrowserRouter as Router } from "react-router-dom";
import { LayoutContainer } from "./layoutContainer";
import { Home } from "../../container/home/home";
import { HairStyleListing } from "../../container/hairStyleListing/hair-style-listing";
import { NoMatch } from "../../container/404/noMatch";
import { SignUp } from "../../container/auth/signUp";
import { SignIn } from "../../container/auth/signIn";
import { ChangePwd } from "../../container/auth/changePwd";
import { ListYourSalon } from "../../container/auth/listYourSalon";
import { ForgotPwd } from "../../container/auth/forgotPwd";

import { RouteLayout } from "./routeLayout";
const layoutConfig = {
  home: { header: true, footer: true },
  hairStyle: { header: true, footer: true },
  signin: { header: false, footer: false },
  signup: { header: false, footer: false },
  login: { header: false, footer: false },
  changePwd: { header: false, footer: false }
};

export const MainRoute = () => {
  return (
    <Router>
      <Switch>
        <Route exact path="/">
          <RouteLayout options={layoutConfig.home}>
            <Home />
          </RouteLayout>
        </Route>
        <Route path="/hair-style-listing">
          <RouteLayout options={layoutConfig.hairStyle}>
            <HairStyleListing />
          </RouteLayout>
        </Route>
        <Route path="/signup">
          <RouteLayout options={layoutConfig.signin}>
            <SignUp />
          </RouteLayout>
        </Route>
        <Route path="/signin">
          <RouteLayout options={layoutConfig.signup}>
            <SignIn />
          </RouteLayout>
        </Route>
        <Route path="/change-password">
          <RouteLayout options={layoutConfig.changePwd}>
            <ChangePwd />
          </RouteLayout>
        </Route>
        <Route path="/forgot-password">
          <RouteLayout options={layoutConfig.changePwd}>
            <ForgotPwd />
          </RouteLayout>
        </Route>
        <Route path="/list-your-salon">
          <RouteLayout options={layoutConfig.changePwd}>
            <ListYourSalon />
          </RouteLayout>
        </Route>
        <Route path="/app">
          <RouteLayout options={layoutConfig.signup}>
            <LayoutContainer />
          </RouteLayout>
        </Route>
        <Route path="*">
          <NoMatch />
        </Route>
      </Switch>
    </Router>
  );
};
