import React from 'react';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import Person from '@material-ui/icons/Person';
import Store from '@material-ui/icons/Store';
import PeopleIcon from '@material-ui/icons/People';
import People from '@material-ui/icons/People';
import LayersIcon from '@material-ui/icons/Layers';
import Event from '@material-ui/icons/Event';

import { NavLink } from "react-router-dom";

export const mainListItems = (
  <div>
    <ListItem button>
     <NavLink  activeClassName='active-menu' to="/app/profile"> 
       <ListItemIcon>
        <Person />
        </ListItemIcon>
        <ListItemText primary="Profile" />
      </NavLink>
    </ListItem>

    <ListItem button>
      <NavLink  activeClassName='active-menu' to="/app/salon"> 
        <ListItemIcon>
          <Store />
        </ListItemIcon>
        <ListItemText primary="Salon" />
        </NavLink>
    </ListItem>
    <ListItem button>
      <NavLink  activeClassName='active-menu' to="/app/services"> 
        <ListItemIcon>
          <PeopleIcon />
        </ListItemIcon>
        <ListItemText primary="Services" />
        </NavLink>
    </ListItem>

    <ListItem button>
      <NavLink  activeClassName='active-menu' to="/app/employee">
        <ListItemIcon>
          <People />
        </ListItemIcon>
        <ListItemText primary="Employee" />
      </NavLink>
    </ListItem>
    <ListItem button>
     <NavLink  activeClassName='active-menu' to="/app/appointment">
      <ListItemIcon>
        <Event />
      </ListItemIcon>
      <ListItemText primary="Appointment" />
      </NavLink>

    </ListItem>
    <ListItem button>
     <NavLink activeClassName='active-menu' to="/app/finances">
        <ListItemIcon>
          <LayersIcon />
        </ListItemIcon>
        <ListItemText primary="Finances" />
      </NavLink>
    </ListItem>
  </div>
);

