import React from 'react';
import { Grid } from '@material-ui/core';
import { useForm } from 'react-hook-form';

import { InputField } from '../../components/formComp/InputField';
import { SelectField }  from '../../components/formComp/SelectField';
import { FormButton } from '../../components/formComp/FormButton';
import { SchemaUpdateProfile } from '../../components/formComp/FormRule';
import  { SelectService } from  '../salonAdmin/selectService';

import './salonAdminComponent.scss';

export const AddNewEmploy=()=>{
 const { register, errors, handleSubmit, formState } = useForm({mode: 'onBlur', validationSchema: SchemaUpdateProfile});
  
    const onSubmit = (data, e) => {
      e.preventDefault();
      console.log(data);
      console.log(formState);
    };
  
    return(
      <div className="form-grid-common"> 
      <form noValidate autoComplete="off" onSubmit={handleSubmit(onSubmit)} >
       <Grid container direction="row" className="form-input-common"> 
        <Grid item  xs={12} md={12} lg={12} className="input-grid">
           <Grid item xs={12} className="grid-input photo-section">
                <div className="title">Upload Employee Photo</div>
                <div className="upload-photo"></div>
            </Grid>

            <Grid item xs={12} className="grid-input">
             <InputField 
                type="text"
                className="input-text" 
                name="fullName"
                error={!!errors.fullName}
                label="Full Name" 
                inputRef={register} />
                {errors.fullName && <div className="formError">{errors.fullName.message}</div>}

            </Grid>
            <Grid item xs={12} className="grid-input">
             <InputField 
                type="text"
                className="input-text" 
                name="emailAddress"
                error={!!errors.fullName}
                label="Email Address" 
                inputRef={register} />
                {errors.emailAddress && <div className="formError">{errors.emailAddress.message}</div>}

            </Grid>
            <Grid item xs={12} className="grid-input">
             <InputField 
                type="text"
                className="input-text" 
                name="phone"
                error={!!errors.phone}
                label="Phone" 
                inputRef={register} />
                {errors.phone && <div className="formError">{errors.phone.message}</div>}

            </Grid>
            <Grid item xs={12} className="grid-input-half">
            <SelectField 
                   options={['Delhi','Pune','Mumbai']}
                   label="Location" />
            </Grid>
            <Grid item xs={12}>
                <SelectService/>
            </Grid>
            
             <Grid item xs={12} className="action-grid-common">
               <FormButton value="Update" className="update-button-profile black-button" />
             </Grid>  
          </Grid>
        </Grid>
      </form>
      </div>
    )
}
