import React from "react";
import { Grid, Checkbox, FormControlLabel } from "@material-ui/core";

export const SelectService = () => {
  const [services, setServices] = React.useState([
    { id: 1, name: "haircutting", label: "Hair cutting", checked: false },
    { id: 2, name: "haircolouring", label: "Hair colouring", checked: false },
    { id: 3, name: "hairstyling", label: "Hair styling", checked: false },
    { id: 4, name: "hairwaxing", label: "Hair waxing", checked: false },
    { id: 5, name: "nailtreatments", label: "Nail treatments", checked: false }
  ]);

  const handleChange = (event, id) => {
    const newService = [...services];
    const updateService = newService.map(item => {
      if (item.id === id) {
        item.checked = event.target.checked;
        return item;
      } else {
        return item;
      }
    });
    setServices(updateService);
  };

  return (
    <>
      <Grid container direction="row">
        {services.map(items => (
          <Grid key={items.id} xs={6} item>
            <FormControlLabel
              control={
                <Checkbox
                  checked={items.checked}
                  onChange={e => handleChange(e, items.id)}
                  name={items.name}
                />
              }
              label={items.label}
            />
          </Grid>
        ))}
      </Grid>
    </>
  );
};
