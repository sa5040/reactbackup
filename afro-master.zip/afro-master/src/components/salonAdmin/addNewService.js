import React from 'react';
import { Grid } from '@material-ui/core';
import { useForm } from 'react-hook-form';

import { InputField } from '../../components/formComp/InputField';
import { FormButton } from '../../components/formComp/FormButton';
import { SchemaUpdateProfile } from '../../components/formComp/FormRule';
import { SelectField }  from '../../components/formComp/SelectField';
import InputAdornment from '@material-ui/core/InputAdornment';
import './salonAdminComponent.scss';

export const AddNewService = () =>{
 const { register, errors, handleSubmit, formState } = useForm({mode: 'onBlur', validationSchema: SchemaUpdateProfile});
  
    const onSubmit = (data, e) => {
      e.preventDefault();
      console.log(data);
      console.log(formState);
    };
  
    return(
      <div className="form-grid-common"> 
      <form noValidate autoComplete="off" onSubmit={handleSubmit(onSubmit)} >
       <Grid container direction="row" className="form-input-common"> 
        <Grid item xs={12} className="grid-input photo-section">
            <div className="title">Upload Style Photo</div>
              <div className="upload-photo"></div>
              
        </Grid>
        <Grid item  xs={12} md={12} lg={12} className="input-grid">
            <Grid item xs={12} className="grid-input">
             <InputField 
                type="text"
                className="input-text" 
                name="country"
                error={!!errors.country}
                label="Country" 
                inputRef={register} />
                {errors.country && <div className="formError">{errors.country.message}</div>}

              </Grid>

              <Grid item xs={12} className="grid-input">
                <InputField 
                    type="text"
                    className="input-text" 
                    name="charges"
                    error={!!errors.country}
                    label="Charges" 
                    InputProps={{
                        startAdornment: <InputAdornment position="start">$</InputAdornment>,
                      }}
                    inputRef={register} />
                    {errors.charges && <div className="formError">{errors.charges.message}</div>}

              </Grid>

              <Grid item xs={12} className="grid-input">
                 <SelectField 
                   options={['Hair cutting','Hair colouring','Hair styling','Hair waxing']}
                   label="Category" />
              </Grid>
              <Grid item xs={12} className="grid-input-half" container direction="row">
                  <Grid item xs={4}>
                    <SelectField 
                     options={[1,2,3,4,5,6,7,8,9,10]}
                     label="Hours" classs="selectMinuts"/>
                   </Grid>

                   <Grid item xs={5} >
                    <SelectField 
                     options={[1,2,3,4,5,6,7,8,9,10,23]}
                     label="Minutes" classs="selectMinuts" />
                   </Grid>
               </Grid>
        
             <Grid item xs={12} className="action-grid-common">
               <FormButton value="Add" className="update-button-profile black-button" />
             </Grid>  
          </Grid>
        </Grid>
      </form>
      </div>
    )
}
