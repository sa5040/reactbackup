import React from 'react';
import { Grid } from '@material-ui/core';
import { useForm } from 'react-hook-form';

import { InputField } from '../../components/formComp/InputField';
import { InputTextarea } from '../../components/formComp/InputTextarea';
import { FormButton } from '../../components/formComp/FormButton';
import { SchemaUpdateProfile } from '../../components/formComp/FormRule';
import './salonAdminComponent.scss';

export const AddNewAddress = () =>{
 const { register, errors, handleSubmit, formState } = useForm({mode: 'onBlur', validationSchema: SchemaUpdateProfile});
  
    const onSubmit = (data, e) => {
      e.preventDefault();
      console.log(data);
      console.log(formState);
    };
  
    return(
      <div className="form-grid-common"> 
      <form noValidate autoComplete="off" onSubmit={handleSubmit(onSubmit)} >
       <Grid container direction="row" className="form-input-common"> 
        <Grid item  xs={12} md={12} lg={12} className="input-grid">
            <Grid item xs={12} className="grid-input">
             <InputField 
                type="text"
                className="input-text" 
                name="country"
                error={!!errors.country}
                label="Country" 
                inputRef={register} />
                {errors.country && <div className="formError">{errors.country.message}</div>}

            </Grid>
            <Grid item xs={12} className="grid-input">
             <InputField 
                type="text"
                className="input-text" 
                name="postcode"
                error={!!errors.postcode}
                label="Postcode" 
                inputRef={register} />
                {errors.postcode && <div className="formError">{errors.postcode.message}</div>}

            </Grid>
            <Grid item xs={12} className="grid-input">
             <InputField 
                type="text"
                className="input-text" 
                name="cityTown"
                error={!!errors.cityTown}
                label="City/Town" 
                inputRef={register} />
                {errors.cityTown && <div className="formError">{errors.cityTown.message}</div>}

            </Grid>

             <Grid item xs={12} className="grid-input">
              <InputField 
                type="text"
                className="input-text" 
                name="telephone"
                error={!!errors.telephone}
                label="Telephone" 
                inputRef={register} />
                {errors.telephone && <div className="formError">{errors.telephone.message}</div>}

             </Grid>
            
             <Grid item  xs={12} md={12} lg={12}> 
              <InputTextarea
                label="Street Address"
                rows="4"
                error={!!errors.streetAddress}
                name="streetAddress"
                className="input-text"
                inputRef={register} />
                {errors.streetAddress && <div className="formError">{errors.streetAddress.message}</div>}

            </Grid> 
          
             <Grid item xs={12} className="action-grid-common">
               <FormButton value="Update" className="update-button-profile black-button" />
             </Grid>  
          </Grid>
        </Grid>
      </form>
      </div>
    )
}
