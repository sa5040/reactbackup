import React from 'react';
import { Grid } from '@material-ui/core';
import { useForm } from 'react-hook-form';

import { InputField } from '../../components/formComp/InputField';
import { InputTextarea } from '../../components/formComp/InputTextarea';
import { FormButton } from '../../components/formComp/FormButton';
import { SchemaUpdateProfile } from '../../components/formComp/FormRule';
import './salonAdminComponent.scss';

export const AddNewCategory = () =>{
 const { register, errors, handleSubmit, formState } = useForm({mode: 'onBlur', validationSchema: SchemaUpdateProfile});
  
    const onSubmit = (data, e) => {
      e.preventDefault();
      console.log(data);
      console.log(formState);
    };
  
    return(
      <div className="form-grid-common"> 
      <form noValidate autoComplete="off" onSubmit={handleSubmit(onSubmit)} >
       <Grid container direction="row" className="form-input-common"> 
        <Grid item  xs={12} md={12} lg={12} className="input-grid">
            <Grid item xs={12} className="grid-input">
             <InputField 
                type="text"
                className="input-text" 
                name="categoryName"
                error={!!errors.categoryName}
                label="Category Name" 
                inputRef={register} />
                {errors.categoryName && <div className="formError">{errors.categoryName.message}</div>}

            </Grid>
            
             <Grid item  xs={12} md={12} lg={12}> 
              <InputTextarea
                label="Description"
                rows="4"
                error={!!errors.description}
                name="description"
                className="input-text"
                inputRef={register} />
                {errors.description && <div className="formError">{errors.description.message}</div>}

            </Grid> 
          
             <Grid item xs={12} className="action-grid-common">
               <FormButton value="Add" className="update-button-profile black-button" />
             </Grid>  
          </Grid>
        </Grid>
      </form>
      </div>
    )
}
